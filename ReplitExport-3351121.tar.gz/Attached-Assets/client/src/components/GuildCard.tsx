import { GuildListResponse } from "@shared/routes";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Link } from "wouter";
import { ExternalLink, Settings, ShieldAlert } from "lucide-react";
import { motion } from "framer-motion";

interface GuildCardProps {
  guild: GuildListResponse[0];
}

export function GuildCard({ guild }: GuildCardProps) {
  const iconUrl = guild.icon 
    ? `https://cdn.discordapp.com/icons/${guild.id}/${guild.icon}.png` 
    : undefined;
  
  const initials = guild.name
    .split(" ")
    .map(n => n[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();

  // Replace with your actual bot invite link
  const inviteLink = `https://discord.com/api/oauth2/authorize?client_id=1234567890&permissions=8&scope=bot%20applications.commands&guild_id=${guild.id}`;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <Card className="group relative overflow-hidden bg-card/50 backdrop-blur-sm border-white/5 hover:border-primary/50 transition-all duration-300 hover:shadow-xl hover:shadow-primary/5">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
        
        <div className="p-6 flex flex-col items-center text-center relative z-10">
          <Avatar className="w-20 h-20 mb-4 border-2 border-border group-hover:border-primary transition-colors duration-300 shadow-lg">
            <AvatarImage src={iconUrl} />
            <AvatarFallback className="text-xl font-bold bg-muted text-muted-foreground">{initials}</AvatarFallback>
          </Avatar>
          
          <h3 className="font-display font-bold text-lg truncate w-full mb-1">
            {guild.name}
          </h3>
          
          <div className="flex items-center gap-2 mb-6">
            <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${guild.owner ? 'bg-amber-500/10 text-amber-500' : 'bg-blue-500/10 text-blue-500'}`}>
              {guild.owner ? 'Owner' : 'Admin'}
            </span>
            {guild.botInGuild && (
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-green-500/10 text-green-500">
                Active
              </span>
            )}
          </div>

          <div className="w-full mt-auto">
            {guild.botInGuild ? (
              <Link href={`/dashboard/${guild.id}/settings`}>
                <Button className="w-full bg-primary/10 hover:bg-primary text-primary hover:text-white border border-primary/20 hover:border-transparent transition-all duration-300 group-hover:translate-y-0">
                  <Settings className="w-4 h-4 mr-2" />
                  Manage Server
                </Button>
              </Link>
            ) : (
              <a href={inviteLink} target="_blank" rel="noopener noreferrer" className="block w-full">
                <Button variant="outline" className="w-full hover:bg-muted/50 border-dashed">
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Invite Bot
                </Button>
              </a>
            )}
          </div>
        </div>
      </Card>
    </motion.div>
  );
}
