import { ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { useUser, useLogout } from "@/hooks/use-auth";
import { 
  LayoutDashboard, 
  Settings, 
  LogOut, 
  Menu,
  Shield,
  BarChart3
} from "lucide-react";
import { SiDiscord } from "react-icons/si";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";

interface DashboardLayoutProps {
  children: ReactNode;
  guildId?: string;
}

export function DashboardLayout({ children, guildId }: DashboardLayoutProps) {
  const [location] = useLocation();
  const { data: user } = useUser();
  const logout = useLogout();

  const handleLogout = () => {
    logout.mutate();
  };

  const NavItem = ({ href, icon: Icon, label, active }: any) => (
    <Link href={href}>
      <div 
        className={`
          flex items-center gap-3 px-3 py-2 rounded-md transition-all duration-200 cursor-pointer
          ${active 
            ? "bg-primary text-primary-foreground shadow-md shadow-primary/20" 
            : "text-muted-foreground hover:text-foreground hover:bg-muted/50"}
        `}
      >
        <Icon className="w-5 h-5" />
        <span className="font-medium">{label}</span>
      </div>
    </Link>
  );

  const SidebarContent = () => (
    <div className="flex flex-col h-full bg-sidebar-background border-r border-sidebar-accent/50">
      <div className="p-6">
        <Link href="/">
          <div className="flex items-center gap-2 cursor-pointer group">
            <div className="p-2 bg-primary rounded-xl group-hover:scale-110 transition-transform duration-300 shadow-lg shadow-primary/20">
              <SiDiscord className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-bold font-display tracking-tight group-hover:text-primary transition-colors">
              BotPanel
            </span>
          </div>
        </Link>
      </div>

      <div className="flex-1 px-4 space-y-2 py-4">
        <div className="px-2 pb-2">
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">
            Platform
          </p>
          <NavItem 
            href="/dashboard" 
            icon={LayoutDashboard} 
            label="My Servers" 
            active={location === "/dashboard"} 
          />
          <NavItem 
            href="/stats" 
            icon={BarChart3} 
            label="Global Stats" 
            active={location === "/stats"} 
          />
        </div>

        {guildId && (
          <>
            <Separator className="my-2 bg-sidebar-accent" />
            <div className="px-2 pt-2">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">
                Server Management
              </p>
              <NavItem 
                href={`/dashboard/${guildId}/settings`} 
                icon={Settings} 
                label="Configuration" 
                active={location.includes("settings")} 
              />
              <NavItem 
                href={`/dashboard/${guildId}/modules`} 
                icon={Shield} 
                label="Modules" 
                active={location.includes("modules")} 
              />
            </div>
          </>
        )}
      </div>

      <div className="p-4 border-t border-sidebar-accent/50 bg-black/10">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Avatar className="w-9 h-9 border border-border">
              <AvatarImage src={`https://cdn.discordapp.com/avatars/${user?.discordId}/${user?.avatar}.png`} />
              <AvatarFallback>{user?.username.slice(0, 2).toUpperCase()}</AvatarFallback>
            </Avatar>
            <div className="flex flex-col">
              <span className="text-sm font-semibold truncate max-w-[100px]">{user?.username}</span>
              <span className="text-xs text-muted-foreground">Logged in</span>
            </div>
          </div>
          <Button variant="ghost" size="icon" onClick={handleLogout} className="text-muted-foreground hover:text-destructive">
            <LogOut className="w-5 h-5" />
          </Button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      {/* Desktop Sidebar */}
      <aside className="hidden md:block w-64 flex-shrink-0 h-full">
        <SidebarContent />
      </aside>

      {/* Mobile Sidebar */}
      <Sheet>
        <SheetTrigger asChild>
          <Button variant="ghost" size="icon" className="md:hidden absolute top-4 left-4 z-50">
            <Menu className="w-6 h-6" />
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="p-0 w-72 border-r border-sidebar-accent bg-sidebar-background">
          <SidebarContent />
        </SheetContent>
      </Sheet>

      {/* Main Content */}
      <main className="flex-1 h-full overflow-y-auto relative scroll-smooth">
        <div className="max-w-7xl mx-auto p-4 md:p-8 pt-16 md:pt-8 min-h-full">
          {children}
        </div>
      </main>
    </div>
  );
}
