import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl, type UpdateGuildSettingsRequest } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";

export function useGuilds() {
  return useQuery({
    queryKey: [api.guilds.list.path],
    queryFn: async () => {
      const res = await fetch(api.guilds.list.path, { credentials: "include" });
      if (res.status === 401) throw new Error("Unauthorized");
      if (!res.ok) throw new Error("Failed to fetch guilds");
      return api.guilds.list.responses[200].parse(await res.json());
    },
  });
}

export function useGuild(id: string) {
  return useQuery({
    queryKey: [api.guilds.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.guilds.get.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (res.status === 401) throw new Error("Unauthorized");
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch guild");
      return api.guilds.get.responses[200].parse(await res.json());
    },
    enabled: !!id,
  });
}

export function useGuildSettings(id: string) {
  return useQuery({
    queryKey: [api.guilds.settings.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.guilds.settings.get.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (res.status === 401) throw new Error("Unauthorized");
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch settings");
      return api.guilds.settings.get.responses[200].parse(await res.json());
    },
    enabled: !!id,
  });
}

export function useUpdateGuildSettings(id: string) {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (updates: UpdateGuildSettingsRequest) => {
      const url = buildUrl(api.guilds.settings.update.path, { id });
      const res = await fetch(url, {
        method: api.guilds.settings.update.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updates),
        credentials: "include",
      });

      if (!res.ok) {
        if (res.status === 403) throw new Error("You don't have permission to update this guild");
        if (res.status === 401) throw new Error("Unauthorized");
        throw new Error("Failed to update settings");
      }

      return api.guilds.settings.update.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.guilds.settings.get.path, id] });
      toast({
        title: "Settings saved",
        description: "Your guild configuration has been updated successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}
