import { useEffect } from "react";
import { useRoute } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertGuildSettingsSchema } from "@shared/schema";
import { useGuild, useGuildSettings, useUpdateGuildSettings } from "@/hooks/use-guilds";
import { DashboardLayout } from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowLeft, Save } from "lucide-react";
import { Link } from "wouter";
import { z } from "zod";

const formSchema = insertGuildSettingsSchema.pick({
  prefix: true,
  language: true,
  welcomeMessage: true,
  welcomeChannelId: true,
});

type FormValues = z.infer<typeof formSchema>;

export default function GuildSettings() {
  const [_, params] = useRoute("/dashboard/:id/settings");
  const guildId = params?.id || "";

  const { data: guild } = useGuild(guildId);
  const { data: settings, isLoading: isLoadingSettings } = useGuildSettings(guildId);
  const updateSettings = useUpdateGuildSettings(guildId);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      prefix: "!",
      language: "en",
      welcomeMessage: "Welcome to the server, {user}!",
      welcomeChannelId: "",
    },
  });

  // Reset form when settings load
  useEffect(() => {
    if (settings) {
      form.reset({
        prefix: settings.prefix || "!",
        language: settings.language || "en",
        welcomeMessage: settings.welcomeMessage || "",
        welcomeChannelId: settings.welcomeChannelId || "",
      });
    }
  }, [settings, form]);

  const onSubmit = (values: FormValues) => {
    updateSettings.mutate(values);
  };

  if (isLoadingSettings) {
    return (
      <DashboardLayout guildId={guildId}>
        <div className="space-y-6">
          <Skeleton className="h-12 w-1/3" />
          <Skeleton className="h-[400px] w-full" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout guildId={guildId}>
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <Link href="/dashboard">
            <Button variant="ghost" size="icon" className="shrink-0">
              <ArrowLeft className="w-5 h-5" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-display font-bold">Server Settings</h1>
            <p className="text-muted-foreground">Configure global settings for {guild?.name}</p>
          </div>
        </div>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
            <Card className="bg-card/50 backdrop-blur border-white/5">
              <CardHeader>
                <CardTitle>General Configuration</CardTitle>
                <CardDescription>Basic bot settings for this server</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="prefix"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Command Prefix</FormLabel>
                        <FormControl>
                          <Input placeholder="!" {...field} value={field.value || ""} />
                        </FormControl>
                        <FormDescription>
                          Symbol used to trigger bot commands
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="language"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Language</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value || "en"}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select a language" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="en">English</SelectItem>
                            <SelectItem value="es">Español</SelectItem>
                            <SelectItem value="fr">Français</SelectItem>
                            <SelectItem value="de">Deutsch</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormDescription>
                          Language for bot responses
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-card/50 backdrop-blur border-white/5">
              <CardHeader>
                <CardTitle>Welcome Module</CardTitle>
                <CardDescription>Configure automated welcome messages for new members</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <FormField
                  control={form.control}
                  name="welcomeChannelId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Welcome Channel ID</FormLabel>
                      <FormControl>
                        <Input placeholder="123456789012345678" {...field} value={field.value || ""} />
                      </FormControl>
                      <FormDescription>
                        Right click a channel in Discord and select "Copy ID"
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="welcomeMessage"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Welcome Message</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Welcome {user} to the server!" 
                          className="min-h-[100px]"
                          {...field} 
                          value={field.value || ""}
                        />
                      </FormControl>
                      <FormDescription>
                        Variables: {"{user}"} mentions the user, {"{server}"} is server name
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </CardContent>
            </Card>

            <div className="flex justify-end sticky bottom-6 z-10">
              <Button 
                type="submit" 
                disabled={updateSettings.isPending}
                className="shadow-lg shadow-primary/25 bg-primary hover:bg-primary/90 min-w-[150px]"
              >
                {updateSettings.isPending ? (
                  "Saving..."
                ) : (
                  <>
                    <Save className="w-4 h-4 mr-2" />
                    Save Changes
                  </>
                )}
              </Button>
            </div>
          </form>
        </Form>
      </div>
    </DashboardLayout>
  );
}
