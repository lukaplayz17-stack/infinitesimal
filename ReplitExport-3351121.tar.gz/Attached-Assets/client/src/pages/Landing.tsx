import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { SiDiscord } from "react-icons/si";
import { motion } from "framer-motion";
import { useStats } from "@/hooks/use-stats";
import { BarChart3, Shield, Zap } from "lucide-react";

export default function Landing() {
  const { data: stats } = useStats();

  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="absolute inset-0 -z-10 overflow-hidden">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1000px] h-[600px] bg-primary/20 rounded-full blur-[120px] opacity-50" />
        </div>

        <div className="text-center space-y-8 max-w-3xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="text-5xl md:text-7xl font-display font-bold tracking-tight mb-6 bg-gradient-to-r from-white via-primary/50 to-white bg-clip-text text-transparent">
              Manage Your Discord Community
            </h1>
            <p className="text-xl text-muted-foreground mb-8 leading-relaxed">
              The ultimate dashboard for your Discord bot. Configure moderation, welcome messages, and more with a beautiful, modern interface.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Link href="/login">
                <Button size="lg" className="h-14 px-8 text-lg rounded-full bg-primary hover:bg-primary/90 shadow-lg shadow-primary/25 transition-all hover:scale-105">
                  <SiDiscord className="mr-2 w-5 h-5" />
                  Login with Discord
                </Button>
              </Link>
              <a href="#features">
                <Button variant="outline" size="lg" className="h-14 px-8 text-lg rounded-full bg-transparent border-white/10 hover:bg-white/5 backdrop-blur-sm">
                  View Features
                </Button>
              </a>
            </div>
          </motion.div>

          {/* Stats */}
          <motion.div 
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="grid grid-cols-2 md:grid-cols-3 gap-8 pt-12 border-t border-white/5"
          >
            <div className="text-center">
              <div className="text-3xl font-bold font-display">{stats?.serverCount || "100+"}</div>
              <div className="text-sm text-muted-foreground uppercase tracking-wider">Servers</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold font-display">{stats?.userCount || "50k+"}</div>
              <div className="text-sm text-muted-foreground uppercase tracking-wider">Users</div>
            </div>
            <div className="text-center col-span-2 md:col-span-1">
              <div className="text-3xl font-bold font-display">{stats ? `${Math.floor(stats.uptime / 3600)}h` : "99.9%"}</div>
              <div className="text-sm text-muted-foreground uppercase tracking-wider">Uptime</div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features Grid */}
      <section id="features" className="py-24 px-4 bg-black/20">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-display font-bold mb-4">Powerful Features</h2>
            <p className="text-muted-foreground">Everything you need to build a better community</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="p-8 rounded-2xl bg-card border border-white/5 hover:border-primary/20 transition-colors">
              <div className="w-12 h-12 rounded-xl bg-blue-500/10 flex items-center justify-center mb-6">
                <Shield className="w-6 h-6 text-blue-500" />
              </div>
              <h3 className="text-xl font-bold mb-3">Moderation</h3>
              <p className="text-muted-foreground">Keep your server safe with automated filters, kick/ban commands, and detailed logs.</p>
            </div>
            <div className="p-8 rounded-2xl bg-card border border-white/5 hover:border-primary/20 transition-colors">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-6">
                <Zap className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-3">Custom Commands</h3>
              <p className="text-muted-foreground">Create simple or complex custom responses to engage your members.</p>
            </div>
            <div className="p-8 rounded-2xl bg-card border border-white/5 hover:border-primary/20 transition-colors">
              <div className="w-12 h-12 rounded-xl bg-purple-500/10 flex items-center justify-center mb-6">
                <BarChart3 className="w-6 h-6 text-purple-500" />
              </div>
              <h3 className="text-xl font-bold mb-3">Analytics</h3>
              <p className="text-muted-foreground">Track server growth, active members, and message activity over time.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 text-center text-muted-foreground border-t border-white/5">
        <div className="max-w-7xl mx-auto px-4">
          <p>© 2024 BotPanel. Not affiliated with Discord.</p>
        </div>
      </footer>
    </div>
  );
}
