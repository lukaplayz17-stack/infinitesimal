import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { SiDiscord } from "react-icons/si";

export default function Login() {
  const handleLogin = () => {
    window.location.href = "/api/auth/discord";
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center p-4 bg-background overflow-hidden relative">
      {/* Background decorations */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-primary/20 rounded-full blur-[100px] -translate-y-1/2" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-purple-500/20 rounded-full blur-[100px] translate-y-1/2" />
      </div>

      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md relative z-10"
      >
        <Card className="p-8 border-white/10 bg-black/40 backdrop-blur-xl shadow-2xl">
          <div className="text-center mb-8">
            <motion.div
              initial={{ y: -20 }}
              animate={{ y: 0 }}
              transition={{ delay: 0.2 }}
              className="w-16 h-16 bg-primary rounded-2xl mx-auto mb-6 flex items-center justify-center shadow-lg shadow-primary/25"
            >
              <SiDiscord className="w-9 h-9 text-white" />
            </motion.div>
            <h1 className="text-3xl font-display font-bold mb-2 bg-gradient-to-br from-white to-white/60 bg-clip-text text-transparent">
              Welcome Back
            </h1>
            <p className="text-muted-foreground">
              Sign in to manage your Discord servers and bot configuration
            </p>
          </div>

          <div className="space-y-4">
            <Button 
              onClick={handleLogin}
              className="w-full h-12 text-base font-medium bg-[#5865F2] hover:bg-[#4752C4] shadow-lg shadow-[#5865F2]/25 transition-all hover:scale-[1.02] active:scale-[0.98]"
            >
              <SiDiscord className="w-5 h-5 mr-3" />
              Login with Discord
            </Button>
            
            <div className="text-center text-xs text-muted-foreground mt-6">
              By logging in, you agree to our Terms of Service and Privacy Policy.
            </div>
          </div>
        </Card>
      </motion.div>
    </div>
  );
}
