## Packages
framer-motion | Page transitions and UI animations
react-icons | Brand icons like Discord logo (SiDiscord)
recharts | Visualizing bot statistics

## Notes
Discord Auth login URL is /api/auth/discord
Dark mode is the default and only theme
