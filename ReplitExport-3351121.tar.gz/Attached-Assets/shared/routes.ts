import { z } from 'zod';
import { insertGuildSettingsSchema, guildSettings } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
  unauthorized: z.object({
    message: z.string(),
  }),
};

export const api = {
  auth: {
    me: {
      method: 'GET' as const,
      path: '/api/me',
      responses: {
        200: z.object({
          id: z.number(),
          discordId: z.string(),
          username: z.string(),
          avatar: z.string().nullable(),
        }),
        401: errorSchemas.unauthorized,
      },
    },
    logout: {
      method: 'POST' as const,
      path: '/api/auth/logout',
      responses: {
        200: z.object({ message: z.string() }),
      },
    },
  },
  guilds: {
    list: {
      method: 'GET' as const,
      path: '/api/guilds',
      responses: {
        200: z.array(z.object({
          id: z.string(),
          name: z.string(),
          icon: z.string().nullable(),
          owner: z.boolean(),
          permissions: z.string(),
          botInGuild: z.boolean(),
        })),
        401: errorSchemas.unauthorized,
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/guilds/:id',
      responses: {
        200: z.object({
          id: z.string(),
          name: z.string(),
          icon: z.string().nullable(),
        }),
        404: errorSchemas.notFound,
        401: errorSchemas.unauthorized,
      },
    },
    settings: {
      get: {
        method: 'GET' as const,
        path: '/api/guilds/:id/settings',
        responses: {
          200: z.custom<typeof guildSettings.$inferSelect>(),
          404: errorSchemas.notFound,
          401: errorSchemas.unauthorized,
        },
      },
      update: {
        method: 'PATCH' as const,
        path: '/api/guilds/:id/settings',
        input: insertGuildSettingsSchema.partial(),
        responses: {
          200: z.custom<typeof guildSettings.$inferSelect>(),
          401: errorSchemas.unauthorized,
          403: z.object({ message: z.string() }), // Forbidden if not admin
        },
      },
    },
  },
  stats: {
    get: {
      method: 'GET' as const,
      path: '/api/stats',
      responses: {
        200: z.object({
          serverCount: z.number(),
          userCount: z.number(),
          uptime: z.number(),
        }),
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}

export type GuildListResponse = z.infer<typeof api.guilds.list.responses[200]>;
export type UserResponse = z.infer<typeof api.auth.me.responses[200]>;
