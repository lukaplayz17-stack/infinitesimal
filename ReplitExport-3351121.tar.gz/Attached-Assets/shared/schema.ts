import { sql } from "drizzle-orm";
import { pgTable, text, serial, boolean, timestamp, jsonb, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// === TABLE DEFINITIONS ===

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  discordId: text("discord_id").notNull().unique(),
  username: text("username").notNull(),
  discriminator: text("discriminator").notNull(),
  avatar: text("avatar"),
  accessToken: text("access_token"), // For refreshing/fetching guilds
  refreshToken: text("refresh_token"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const guilds = pgTable("guilds", {
  id: serial("id").primaryKey(),
  discordId: text("discord_id").notNull().unique(),
  name: text("name").notNull(),
  icon: text("icon"),
  ownerId: text("owner_id").notNull(), // Discord User ID
  botInGuild: boolean("bot_in_guild").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const guildSettings = pgTable("guild_settings", {
  id: serial("id").primaryKey(),
  guildId: text("guild_id").notNull().unique(), // References guilds.discordId
  prefix: text("prefix").default("!"),
  language: text("language").default("en"),
  welcomeMessage: text("welcome_message"),
  welcomeChannelId: text("welcome_channel_id"),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const commandUsage = pgTable("command_usage", {
  id: serial("id").primaryKey(),
  command: text("command").notNull(),
  userId: text("user_id").notNull(),
  guildId: text("guild_id"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const auditLogs = pgTable("audit_logs", {
  id: serial("id").primaryKey(),
  guildId: text("guild_id").notNull(),
  userId: text("user_id").notNull(), // The user who performed the action
  action: text("action").notNull(),
  details: text("details"), // JSON string or description
  createdAt: timestamp("created_at").defaultNow(),
});

// Session table for connect-pg-simple
export const session = pgTable("session", {
  sid: varchar("sid").primaryKey(),
  sess: jsonb("sess").notNull(),
  expire: timestamp("expire").notNull(),
});

export const guildRoles = pgTable("guild_roles", {
  id: serial("id").primaryKey(),
  guildId: text("guild_id").notNull(),
  roleName: text("role_name").notNull(), // e.g., 'admin', 'moderator', 'editor'
  permissions: jsonb("permissions").notNull(), // e.g., { canEditSettings: true, canViewAuditLogs: true }
  discordRoleIds: text("discord_role_ids").array().notNull(), // Array of Discord Role IDs that map to this internal role
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => {
  return {
    guildRoleUnique: sql`UNIQUE(${table.guildId}, ${table.roleName})`
  };
});

// === SCHEMAS ===

export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true });
export const insertGuildSchema = createInsertSchema(guilds).omit({ id: true, createdAt: true, updatedAt: true });
export const insertGuildSettingsSchema = createInsertSchema(guildSettings).omit({ id: true, updatedAt: true });
export const insertCommandUsageSchema = createInsertSchema(commandUsage).omit({ id: true, createdAt: true });
export const insertAuditLogSchema = createInsertSchema(auditLogs).omit({ id: true, createdAt: true });
export const insertGuildRoleSchema = createInsertSchema(guildRoles).omit({ id: true, updatedAt: true });

// === TYPES ===

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type GuildRole = typeof guildRoles.$inferSelect;
export type InsertGuildRole = z.infer<typeof insertGuildRoleSchema>;

export type AuditLog = typeof auditLogs.$inferSelect;
export type InsertAuditLog = z.infer<typeof insertAuditLogSchema>;

export type Guild = typeof guilds.$inferSelect;
export type InsertGuild = z.infer<typeof insertGuildSchema>;

export type GuildSettings = typeof guildSettings.$inferSelect;
export type InsertGuildSettings = z.infer<typeof insertGuildSettingsSchema>;

// API Types
export type UpdateGuildSettingsRequest = Partial<InsertGuildSettings>;

export type GuildResponse = Guild & {
  settings?: GuildSettings;
  permissions?: string; // For frontend logic
};

// Discord OAuth Profile
export interface DiscordProfile {
  id: string;
  username: string;
  discriminator: string;
  avatar: string | null;
  email?: string;
  guilds?: DiscordGuild[];
}

export interface DiscordGuild {
  id: string;
  name: string;
  icon: string | null;
  owner: boolean;
  permissions: string;
  features: string[];
}
