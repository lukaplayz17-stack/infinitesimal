import { db } from "./db";
import {
  users, guilds, guildSettings, commandUsage, auditLogs, guildRoles,
  type User, type InsertUser,
  type Guild, type InsertGuild,
  type GuildSettings, type InsertGuildSettings,
  type CommandUsage, type InsertCommandUsage,
  type AuditLog, type InsertAuditLog,
  type GuildRole, type InsertGuildRole
} from "@shared/schema";
import { eq, sql, and } from "drizzle-orm";

export interface IStorage {
  // ... existing methods ...
  getUser(id: number): Promise<User | undefined>;
  getUserByDiscordId(discordId: string): Promise<User | undefined>;
  upsertUser(user: InsertUser): Promise<User>;
  getGuild(id: string): Promise<Guild | undefined>;
  getGuildsByOwner(ownerId: string): Promise<Guild[]>;
  upsertGuild(guild: InsertGuild): Promise<Guild>;
  getGuildSettings(guildId: string): Promise<GuildSettings | undefined>;
  upsertGuildSettings(settings: InsertGuildSettings): Promise<GuildSettings>;
  updateGuildSettings(guildId: string, settings: Partial<InsertGuildSettings>): Promise<GuildSettings>;
  logCommandUsage(usage: InsertCommandUsage): Promise<void>;
  createAuditLog(log: InsertAuditLog): Promise<void>;
  getAuditLogs(guildId: string): Promise<AuditLog[]>;

  // Guild Roles (RBAC)
  getGuildRoles(guildId: string): Promise<GuildRole[]>;
  upsertGuildRole(role: InsertGuildRole): Promise<GuildRole>;
  deleteGuildRole(id: number): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByDiscordId(discordId: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.discordId, discordId));
    return user;
  }

  async upsertUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser)
      .onConflictDoUpdate({
        target: users.discordId,
        set: {
          username: insertUser.username,
          discriminator: insertUser.discriminator,
          avatar: insertUser.avatar,
          accessToken: insertUser.accessToken,
          refreshToken: insertUser.refreshToken,
        }
      })
      .returning();
    return user;
  }

  async getGuild(discordId: string): Promise<Guild | undefined> {
    const [guild] = await db.select().from(guilds).where(eq(guilds.discordId, discordId));
    return guild;
  }

  async getGuildsByOwner(ownerId: string): Promise<Guild[]> {
    return db.select().from(guilds).where(eq(guilds.ownerId, ownerId));
  }

  async upsertGuild(insertGuild: InsertGuild): Promise<Guild> {
    const [guild] = await db.insert(guilds).values(insertGuild)
      .onConflictDoUpdate({
        target: guilds.discordId,
        set: {
          name: insertGuild.name,
          icon: insertGuild.icon,
          ownerId: insertGuild.ownerId,
          updatedAt: new Date(),
        }
      })
      .returning();
    return guild;
  }

  async getGuildSettings(guildId: string): Promise<GuildSettings | undefined> {
    const [settings] = await db.select().from(guildSettings).where(eq(guildSettings.guildId, guildId));
    return settings;
  }

  async upsertGuildSettings(insertSettings: InsertGuildSettings): Promise<GuildSettings> {
    const [settings] = await db.insert(guildSettings).values(insertSettings)
      .onConflictDoUpdate({
        target: guildSettings.guildId,
        set: { ...insertSettings, updatedAt: new Date() }
      })
      .returning();
    return settings;
  }

  async updateGuildSettings(guildId: string, updates: Partial<InsertGuildSettings>): Promise<GuildSettings> {
    const [settings] = await db.update(guildSettings)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(guildSettings.guildId, guildId))
      .returning();
    return settings;
  }

  async logCommandUsage(usage: InsertCommandUsage): Promise<void> {
    await db.insert(commandUsage).values(usage);
  }

  async createAuditLog(log: InsertAuditLog): Promise<void> {
    await db.insert(auditLogs).values(log);
  }

  async getAuditLogs(guildId: string): Promise<AuditLog[]> {
    return db.select().from(auditLogs).where(eq(auditLogs.guildId, guildId)).orderBy(sql`${auditLogs.createdAt} DESC`).limit(50);
  }

  async getGuildRoles(guildId: string): Promise<GuildRole[]> {
    return db.select().from(guildRoles).where(eq(guildRoles.guildId, guildId));
  }

  async upsertGuildRole(insertRole: InsertGuildRole): Promise<GuildRole> {
    const [role] = await db.insert(guildRoles).values(insertRole)
      .onConflictDoUpdate({
        target: [guildRoles.guildId, guildRoles.roleName],
        set: { ...insertRole, updatedAt: new Date() }
      })
      .returning();
    return role;
  }

  async deleteGuildRole(id: number): Promise<void> {
    await db.delete(guildRoles).where(eq(guildRoles.id, id));
  }
}

export const storage = new DatabaseStorage();
