import { Client, GatewayIntentBits } from 'discord.js';

export const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
  ]
});

client.once('ready', () => {
  console.log(`Logged in as ${client.user?.tag}!`);
});

client.on('guildCreate', async (guild) => {
  console.log(`Joined guild: ${guild.name}`);
  // We could sync to DB here
});

export function startBot() {
  if (!process.env.DISCORD_BOT_TOKEN) {
    console.warn("DISCORD_BOT_TOKEN not set. Bot will not start.");
    return;
  }
  client.login(process.env.DISCORD_BOT_TOKEN).catch(err => {
    console.error("Failed to login to Discord:", err);
  });
}
