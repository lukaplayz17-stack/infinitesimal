import type { Express, Request, Response, NextFunction } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api, errorSchemas } from "@shared/routes";
import { z } from "zod";
import passport from "passport";
import { Strategy as DiscordStrategy } from "passport-discord";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { pool } from "./db";
import { startBot, client } from "./bot";

const pgSession = connectPg(session);

// Permission checking middleware helper
async function ensureGuildPermission(req: Request, res: Response, next: NextFunction) {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: "Not authenticated" });
  }

  const user = req.user as any;
  const guildId = req.params.id;

  if (!guildId) {
    return res.status(400).json({ message: "Guild ID required" });
  }

  try {
    // 1. Fetch user's guilds from Discord to verify permission
    // This is the source of truth.
    const response = await fetch('https://discord.com/api/users/@me/guilds', {
      headers: { Authorization: `Bearer ${user.accessToken}` }
    });

    if (!response.ok) {
      if (response.status === 401) {
        // Token expired? In MVP we might just fail, later implement refresh
        return res.status(401).json({ message: "Discord token expired" });
      }
      throw new Error("Failed to verify guild permissions");
    }

    const guilds: any[] = await response.json();
    const targetGuild = guilds.find(g => g.id === guildId);

    if (!targetGuild) {
      return res.status(403).json({ message: "You are not a member of this guild" });
    }

    // Check for MANAGE_GUILD (0x20) or ADMINISTRATOR (0x8)
    const permissions = BigInt(targetGuild.permissions);
    const isDiscordAdmin = (permissions & BigInt(0x20)) === BigInt(0x20) || (permissions & BigInt(0x8)) === BigInt(0x8);

    if (isDiscordAdmin) {
      return next();
    }

    // 2. Fallback to RBAC Roles if not a Discord Admin
    const roles = await storage.getGuildRoles(guildId);
    if (roles.length > 0) {
      // Fetch member's roles in this guild from Discord
      const memberResponse = await fetch(`https://discord.com/api/guilds/${guildId}/members/${user.discordId}`, {
        headers: { Authorization: `Bot ${process.env.DISCORD_BOT_TOKEN}` }
      });

      if (memberResponse.ok) {
        const memberData = await memberResponse.json();
        const memberRoles: string[] = memberData.roles;

        // Check if any of the member's Discord roles match our assigned roles
        const matchingRole = roles.find(r => r.discordRoleIds.some(id => memberRoles.includes(id)));
        
        if (matchingRole) {
          // You could further check specific permissions inside matchingRole.permissions here
          return next();
        }
      }
    }

    return res.status(403).json({ message: "Missing required permissions or roles" });
  } catch (err) {
    console.error("Guild permission check error:", err);
    res.status(500).json({ message: "Failed to verify permissions" });
  }
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // === SESSION SETUP ===
  app.use(session({
    store: new pgSession({
      pool: pool,
      tableName: 'session'
    }),
    secret: process.env.SESSION_SECRET || 'secret',
    resave: false,
    saveUninitialized: false,
    cookie: {
      maxAge: 30 * 24 * 60 * 60 * 1000 // 30 days
    }
  }));

  app.use(passport.initialize());
  app.use(passport.session());

  // === PASSPORT SETUP ===
  passport.serializeUser((user: any, done) => {
    done(null, user.id);
  });

  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (err) {
      done(err);
    }
  });

  if (process.env.DISCORD_CLIENT_ID && process.env.DISCORD_CLIENT_SECRET) {
    passport.use(new DiscordStrategy({
      clientID: process.env.DISCORD_CLIENT_ID,
      clientSecret: process.env.DISCORD_CLIENT_SECRET,
      callbackURL: `${process.env.REPL_SLUG ? `https://${process.env.REPL_SLUG}.${process.env.REPL_OWNER}.repl.co` : 'http://0.0.0.0:5000'}/api/auth/discord/callback`,
      scope: ['identify', 'guilds']
    }, async (accessToken, refreshToken, profile, done) => {
      try {
        const user = await storage.upsertUser({
          discordId: profile.id,
          username: profile.username,
          discriminator: profile.discriminator,
          avatar: profile.avatar,
          accessToken,
          refreshToken,
        });
        return done(null, user);
      } catch (err) {
        return done(err as Error);
      }
    }));
  } else {
    console.warn("DISCORD_CLIENT_ID or DISCORD_CLIENT_SECRET missing. Auth will not work.");
  }

  // === AUTH ROUTES ===
  app.get('/api/auth/discord', passport.authenticate('discord'));

  app.get('/api/auth/discord/callback', 
    passport.authenticate('discord', {
      failureRedirect: '/login',
      successRedirect: '/dashboard'
    })
  );

  app.post(api.auth.logout.path, (req, res, next) => {
    req.logout((err) => {
      if (err) return next(err);
      res.json({ message: "Logged out" });
    });
  });

  app.get(api.auth.me.path, (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    const user = req.user as any;
    res.json({
      id: user.id,
      discordId: user.discordId,
      username: user.username,
      avatar: user.avatar,
    });
  });

  // === API ROUTES ===

  // List Guilds (Fetch from Discord using access token, then merge with DB data)
  app.get(api.guilds.list.path, async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    const user = req.user as any;

    try {
      // 1. Fetch guilds from Discord API
      const response = await fetch('https://discord.com/api/users/@me/guilds', {
        headers: { Authorization: `Bearer ${user.accessToken}` }
      });
      
      if (!response.ok) {
        throw new Error("Failed to fetch guilds from Discord");
      }

      const discordGuilds: any[] = await response.json();

      // 2. Filter for MANAGE_GUILD (0x20)
      const adminGuilds = discordGuilds.filter(g => (BigInt(g.permissions) & BigInt(0x20)) === BigInt(0x20));

      // 3. Check which ones the bot is in
      // We can use the bot client cache if available, or just check our DB if we sync
      // For real-time accuracy, checking bot cache is best.
      const guildsWithBotStatus = adminGuilds.map(g => ({
        id: g.id,
        name: g.name,
        icon: g.icon,
        owner: g.owner,
        permissions: g.permissions,
        botInGuild: client.guilds.cache.has(g.id)
      }));

      res.json(guildsWithBotStatus);
    } catch (err) {
      console.error(err);
      res.status(500).json({ message: "Failed to fetch guilds" });
    }
  });

  app.get(api.guilds.get.path, ensureGuildPermission, async (req, res) => {
    // ensureGuildPermission handles auth and permission checks
    const guildId = req.params.id;
    // We can fetch from Discord cache or just return basic info we validated
    // Fetch from Discord API again? Or pass data from middleware?
    // For now, let's just return what we can or what we have in DB
    // Ideally we should cache the guild info in `req` from middleware to save a call.
    
    const settings = await storage.getGuildSettings(guildId);
    
    // We'll return basic info - in a real app, we might want to fetch full details
    res.json({ 
      id: guildId, 
      name: "Guild Name (Fetch via API)", 
      icon: null 
    });
  });

  app.get(api.guilds.settings.get.path, ensureGuildPermission, async (req, res) => {
    const guildId = req.params.id;
    
    let settings = await storage.getGuildSettings(guildId);
    if (!settings) {
      // Create default settings if not exists
      settings = await storage.upsertGuildSettings({ guildId });
    }
    
    res.json(settings);
  });

  app.patch(api.guilds.settings.update.path, ensureGuildPermission, async (req, res) => {
    const guildId = req.params.id;
    const updates = req.body;
    const user = req.user as any;
    
    const settings = await storage.updateGuildSettings(guildId, updates);

    // Audit Log
    await storage.createAuditLog({
      guildId,
      userId: user.discordId,
      action: "UPDATE_SETTINGS",
      details: JSON.stringify(updates)
    });

    res.json(settings);
  });

  app.get(api.stats.get.path, (req, res) => {
    res.json({
      serverCount: client.guilds.cache.size,
      userCount: client.users.cache.size, // Approximate
      uptime: client.uptime || 0
    });
  });

  // Start the bot
  startBot();

  return httpServer;
}
