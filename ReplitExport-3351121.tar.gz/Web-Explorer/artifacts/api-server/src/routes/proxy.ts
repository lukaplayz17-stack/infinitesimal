import { Router, type IRouter, type Request, type Response } from "express";
import * as cheerio from "cheerio";
import { Readable } from "node:stream";
import { LRUCache } from "lru-cache";

const router: IRouter = Router();

interface PageCacheEntry {
  html: string;
  finalUrl: string;
  status: number;
}

// Cache up to 300 rewritten pages for 90 seconds each
const pageCache = new LRUCache<string, PageCacheEntry>({
  max: 300,
  ttl: 90_000,
});

const USER_AGENT =
  "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36";

const PAGE_PATH = "/api/proxy/page";
const ASSET_PATH = "/api/proxy/asset";

const HOP_BY_HOP = new Set([
  "connection",
  "keep-alive",
  "proxy-authenticate",
  "proxy-authorization",
  "te",
  "trailers",
  "transfer-encoding",
  "upgrade",
  "content-encoding",
  "content-length",
  "content-security-policy",
  "content-security-policy-report-only",
  "x-frame-options",
  "x-content-type-options",
  "strict-transport-security",
  "permissions-policy",
  "cross-origin-embedder-policy",
  "cross-origin-opener-policy",
  "cross-origin-resource-policy",
  "set-cookie",
]);

function isLikelyUrl(input: string): boolean {
  if (/^[a-z][a-z0-9+.-]*:\/\//i.test(input)) return true;
  if (/^[a-z0-9-]+(\.[a-z0-9-]+)+(\/.*)?$/i.test(input)) return true;
  return false;
}

function normalizeInputToUrl(input: string): string {
  const trimmed = input.trim();
  if (!trimmed) return "https://duckduckgo.com/";
  if (isLikelyUrl(trimmed)) {
    if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(trimmed)) {
      return `https://${trimmed}`;
    }
    return trimmed;
  }
  return `https://duckduckgo.com/html/?q=${encodeURIComponent(trimmed)}`;
}

type ProxyBackend = "direct" | "allorigins" | "corsproxy";

const VALID_BACKENDS: ProxyBackend[] = ["direct", "allorigins", "corsproxy"];

function parseBackend(raw: unknown): ProxyBackend {
  if (typeof raw === "string" && (VALID_BACKENDS as string[]).includes(raw)) {
    return raw as ProxyBackend;
  }
  return "direct";
}

function buildPageProxyUrl(absoluteUrl: string, backend: ProxyBackend): string {
  const params = new URLSearchParams({ url: absoluteUrl });
  if (backend !== "direct") params.set("backend", backend);
  return `${PAGE_PATH}?${params.toString()}`;
}

function buildAssetProxyUrl(absoluteUrl: string, backend: ProxyBackend): string {
  const params = new URLSearchParams({ url: absoluteUrl });
  if (backend !== "direct") params.set("backend", backend);
  return `${ASSET_PATH}?${params.toString()}`;
}

function resolveUrl(base: string, relative: string): string | null {
  try {
    return new URL(relative, base).toString();
  } catch {
    return null;
  }
}

function rewriteCss(cssText: string, baseUrl: string, backend: ProxyBackend): string {
  return cssText.replace(
    /url\(\s*(['"]?)([^'")]+)\1\s*\)/gi,
    (match, quote, raw) => {
      const trimmed = raw.trim();
      if (!trimmed || trimmed.startsWith("data:") || trimmed.startsWith("#")) {
        return match;
      }
      const abs = resolveUrl(baseUrl, trimmed);
      if (!abs) return match;
      return `url(${quote}${buildAssetProxyUrl(abs, backend)}${quote})`;
    },
  );
}

function rewriteHtml(html: string, baseUrl: string, backend: ProxyBackend): string {
  const $ = cheerio.load(html);

  $("base").remove();
  $("meta[http-equiv='content-security-policy' i]").remove();
  $("meta[http-equiv='refresh' i]").remove();

  const ASSET_ATTRS: Array<[string, string]> = [
    ["img", "src"],
    ["img", "data-src"],
    ["source", "src"],
    ["source", "srcset"],
    ["img", "srcset"],
    ["video", "src"],
    ["video", "poster"],
    ["audio", "src"],
    ["script", "src"],
    ["link", "href"],
    ["use", "href"],
    ["use", "xlink:href"],
    ["object", "data"],
    ["embed", "src"],
    ["track", "src"],
    ["iframe", "src"],
  ];

  for (const [tag, attr] of ASSET_ATTRS) {
    $(tag).each((_i, el) => {
      const $el = $(el);
      const val = $el.attr(attr);
      if (!val) return;
      if (attr === "srcset") {
        const rewritten = val
          .split(",")
          .map((part) => {
            const p = part.trim();
            if (!p) return p;
            const [u, ...descriptor] = p.split(/\s+/);
            if (!u || u.startsWith("data:")) return p;
            const abs = resolveUrl(baseUrl, u);
            if (!abs) return p;
            return [buildAssetProxyUrl(abs, backend), ...descriptor].join(" ");
          })
          .join(", ");
        $el.attr(attr, rewritten);
        return;
      }
      if (val.startsWith("data:") || val.startsWith("javascript:") || val.startsWith("#") || val.startsWith("blob:")) {
        return;
      }
      const abs = resolveUrl(baseUrl, val);
      if (!abs) return;
      $el.attr(attr, buildAssetProxyUrl(abs, backend));
    });
  }

  $("a").each((_i, el) => {
    const $el = $(el);
    const href = $el.attr("href");
    if (!href) return;
    if (
      href.startsWith("javascript:") ||
      href.startsWith("mailto:") ||
      href.startsWith("tel:") ||
      href.startsWith("#")
    ) {
      return;
    }
    const abs = resolveUrl(baseUrl, href);
    if (!abs) return;
    $el.attr("href", buildPageProxyUrl(abs, backend));
    $el.attr("target", "_top");
    $el.removeAttr("ping");
  });

  $("form").each((_i, el) => {
    const $el = $(el);
    const action = $el.attr("action") || baseUrl;
    const abs = resolveUrl(baseUrl, action);
    if (!abs) return;
    const method = ($el.attr("method") || "get").toLowerCase();
    if (method === "get") {
      $el.attr("action", PAGE_PATH);
      $el.attr("method", "get");
      $el.attr("target", "_top");
      $el.prepend(`<input type="hidden" name="__proxy_target" value="${escapeHtmlAttr(abs)}">`);
      if (backend !== "direct") {
        $el.prepend(`<input type="hidden" name="backend" value="${escapeHtmlAttr(backend)}">`);
      }
    } else {
      $el.attr("action", buildPageProxyUrl(abs, backend));
      $el.attr("target", "_top");
    }
  });

  $("style").each((_i, el) => {
    const $el = $(el);
    const css = $el.html();
    if (!css) return;
    $el.text(rewriteCss(css, baseUrl, backend));
  });

  $("[style]").each((_i, el) => {
    const $el = $(el);
    const style = $el.attr("style");
    if (!style) return;
    $el.attr("style", rewriteCss(style, baseUrl, backend));
  });

  const injection = `
<style>html,body{max-width:100% !important;}</style>
<script>
(function(){
  try {
    var origin = window.location.origin;
    var pagePath = ${JSON.stringify(PAGE_PATH)};
    function postNav(target) {
      try {
        if (window.parent && window.parent !== window) {
          window.parent.postMessage({ __proxyNav: true, url: target }, "*");
        }
      } catch(e) {}
    }
    var origAssign = window.location.assign.bind(window.location);
    var origReplace = window.location.replace.bind(window.location);
    document.addEventListener("click", function(ev){
      var a = ev.target && ev.target.closest && ev.target.closest("a[href]");
      if (!a) return;
      var href = a.getAttribute("href");
      if (!href) return;
      if (href.indexOf(pagePath) === 0 || href.indexOf(origin + pagePath) === 0) {
        try {
          var u = new URL(href, origin);
          var target = u.searchParams.get("url");
          if (target) postNav(target);
        } catch(e) {}
      }
    }, true);
  } catch(e) {}
})();
</script>
`;
  $("head").prepend(injection);

  return $.html();
}

function escapeHtmlAttr(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/"/g, "&quot;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function copyResponseHeaders(upstream: globalThis.Response, res: Response) {
  upstream.headers.forEach((value, key) => {
    if (HOP_BY_HOP.has(key.toLowerCase())) return;
    try {
      res.setHeader(key, value);
    } catch {
      // ignore invalid headers
    }
  });
  res.removeHeader("X-Frame-Options");
  res.removeHeader("Content-Security-Policy");
}

function wrapWithBackend(targetUrl: string, backend: ProxyBackend): string {
  switch (backend) {
    case "allorigins":
      return `https://api.allorigins.win/raw?url=${encodeURIComponent(targetUrl)}`;
    case "corsproxy":
      return `https://corsproxy.io/?url=${encodeURIComponent(targetUrl)}`;
    case "direct":
    default:
      return targetUrl;
  }
}

const UPSTREAM_TIMEOUT_MS = 20_000;

async function fetchUpstream(
  targetUrl: string,
  backend: ProxyBackend,
  init: RequestInit = {},
): Promise<globalThis.Response> {
  const headers = new Headers(init.headers || {});
  if (!headers.has("user-agent")) headers.set("user-agent", USER_AGENT);
  if (!headers.has("accept"))
    headers.set(
      "accept",
      "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    );
  if (!headers.has("accept-language")) headers.set("accept-language", "en-US,en;q=0.9");
  if (!headers.has("accept-encoding")) headers.set("accept-encoding", "gzip, br, deflate");
  const finalUrl = wrapWithBackend(targetUrl, backend);

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), UPSTREAM_TIMEOUT_MS);
  try {
    const response = await fetch(finalUrl, {
      ...init,
      headers,
      redirect: "follow",
      signal: init.signal ?? controller.signal,
    });
    clearTimeout(timer);
    return response;
  } catch (err) {
    clearTimeout(timer);
    throw err;
  }
}

router.get("/proxy/page", async (req: Request, res: Response) => {
  let raw = (req.query["url"] as string | undefined) ?? "";
  const queryTarget = (req.query["__proxy_target"] as string | undefined) ?? "";
  const backend = parseBackend(req.query["backend"]);
  if (queryTarget && !raw) raw = queryTarget;

  const RESERVED = new Set(["url", "__proxy_target", "backend"]);

  let target: string;
  if (queryTarget) {
    const baseAbs = normalizeInputToUrl(queryTarget);
    const params = new URLSearchParams();
    for (const [k, v] of Object.entries(req.query)) {
      if (RESERVED.has(k)) continue;
      if (typeof v === "string") params.append(k, v);
    }
    const qs = params.toString();
    target = qs ? `${baseAbs}${baseAbs.includes("?") ? "&" : "?"}${qs}` : baseAbs;
  } else if (!raw) {
    res.status(400).json({ error: "Missing url parameter" });
    return;
  } else {
    target = normalizeInputToUrl(raw);
  }

  const cacheKey = `${backend}::${target}`;
  const cached = pageCache.get(cacheKey);
  if (cached) {
    res.setHeader("X-Cache", "HIT");
    res.setHeader("Content-Type", "text/html; charset=utf-8");
    res.setHeader("X-Proxy-Final-Url", encodeURIComponent(cached.finalUrl));
    res.setHeader("X-Proxy-Backend", backend);
    res.removeHeader("X-Frame-Options");
    res.removeHeader("Content-Security-Policy");
    res.status(cached.status).send(cached.html);
    return;
  }

  try {
    const upstream = await fetchUpstream(target, backend);
    const finalUrl = backend === "direct" ? upstream.url || target : target;
    const contentType = upstream.headers.get("content-type") || "";

    if (!contentType.toLowerCase().includes("html")) {
      copyResponseHeaders(upstream, res);
      res.status(upstream.status);
      if (upstream.body) {
        Readable.fromWeb(upstream.body as Parameters<typeof Readable.fromWeb>[0]).pipe(res);
      } else {
        res.end();
      }
      return;
    }

    const html = await upstream.text();
    const rewritten = rewriteHtml(html, finalUrl, backend);
    pageCache.set(cacheKey, { html: rewritten, finalUrl, status: upstream.status });
    res.setHeader("X-Cache", "MISS");
    res.setHeader("Content-Type", "text/html; charset=utf-8");
    res.setHeader("X-Proxy-Final-Url", encodeURIComponent(finalUrl));
    res.setHeader("X-Proxy-Backend", backend);
    res.removeHeader("X-Frame-Options");
    res.removeHeader("Content-Security-Policy");
    res.status(upstream.status).send(rewritten);
  } catch (err) {
    req.log.error({ err, target, backend }, "proxy page fetch failed");
    res.status(502).send(renderErrorPage(target, err));
  }
});

router.get("/proxy/asset", async (req: Request, res: Response) => {
  const raw = (req.query["url"] as string | undefined) ?? "";
  const backend = parseBackend(req.query["backend"]);
  if (!raw) {
    res.status(400).json({ error: "Missing url parameter" });
    return;
  }
  let target: string;
  try {
    target = new URL(raw).toString();
  } catch {
    res.status(400).json({ error: "Invalid url" });
    return;
  }

  try {
    const upstream = await fetchUpstream(target, backend);
    const contentType = upstream.headers.get("content-type") || "";
    copyResponseHeaders(upstream, res);
    res.status(upstream.status);

    if (contentType.toLowerCase().includes("text/css")) {
      const css = await upstream.text();
      res.setHeader("Content-Type", "text/css; charset=utf-8");
      res.setHeader("Cache-Control", "public, max-age=3600");
      res.send(rewriteCss(css, upstream.url || target, backend));
      return;
    }

    // Cache static assets aggressively (images, fonts, scripts, etc.)
    if (!contentType.includes("text/html")) {
      res.setHeader("Cache-Control", "public, max-age=86400, immutable");
    }

    // Stream the response body directly — avoids buffering large files in memory
    if (upstream.body) {
      Readable.fromWeb(upstream.body as Parameters<typeof Readable.fromWeb>[0]).pipe(res);
    } else {
      res.end();
    }
  } catch (err) {
    req.log.error({ err, target, backend }, "proxy asset fetch failed");
    res.status(502).json({ error: "Upstream fetch failed" });
  }
});

router.get("/proxy/resolve", (req: Request, res: Response) => {
  const raw = (req.query["q"] as string | undefined) ?? "";
  if (!raw) {
    res.status(400).json({ error: "Missing q parameter" });
    return;
  }
  const url = normalizeInputToUrl(raw);
  res.json({ url });
});

function renderErrorPage(target: string, err: unknown): string {
  const message = err instanceof Error ? err.message : String(err);
  return `<!doctype html><html><head><meta charset="utf-8"><title>Proxy error</title>
<style>body{font-family:system-ui,sans-serif;background:#0b0b10;color:#e7e7ee;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;padding:24px;}
.card{max-width:520px;background:#15151d;border:1px solid #2a2a36;border-radius:14px;padding:28px;}
h1{margin:0 0 8px;font-size:18px;}
p{margin:8px 0;color:#a2a2b0;font-size:14px;line-height:1.5;}
code{background:#0b0b10;padding:2px 6px;border-radius:6px;font-size:12px;color:#e7e7ee;}</style>
</head><body><div class="card">
<h1>Could not load this page</h1>
<p>The proxy couldn't fetch <code>${escapeHtmlAttr(target)}</code>.</p>
<p>${escapeHtmlAttr(message)}</p>
</div></body></html>`;
}

export default router;
