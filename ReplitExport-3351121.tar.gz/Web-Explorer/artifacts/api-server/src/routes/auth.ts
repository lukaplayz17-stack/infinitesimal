import { Router, type IRouter, type Request, type Response } from "express";
import { randomBytes } from "node:crypto";
import { z } from "zod/v4";
import { db, usersTable } from "@workspace/db";
import { eq, or } from "drizzle-orm";
import { hashPassword, verifyPassword } from "../lib/auth";

const router: IRouter = Router();

const credentialsSchema = z.object({
  email: z.string().trim().toLowerCase().email().max(254),
  password: z.string().min(6).max(200),
});

const resetSchema = z.object({
  email: z.string().trim().toLowerCase().email().max(254),
  recoveryCode: z.string().trim().min(8).max(40),
  newPassword: z.string().min(6).max(200),
});

function publicUser(u: {
  id: string;
  email: string;
  displayName: string | null;
  avatarUrl: string | null;
  createdAt: Date;
}) {
  return {
    id: u.id,
    email: u.email,
    displayName: u.displayName,
    avatarUrl: u.avatarUrl,
    createdAt: u.createdAt.toISOString(),
  };
}

function generateRecoveryCode(): string {
  const hex = randomBytes(8).toString("hex").toUpperCase();
  return `${hex.slice(0, 4)}-${hex.slice(4, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}`;
}

function normalizeRecoveryCode(input: string): string {
  return input.replace(/[^A-Za-z0-9]/g, "").toUpperCase();
}

function getCallbackUrl(req: Request): string {
  const domains = process.env.REPLIT_DOMAINS?.split(",")[0];
  const devDomain = process.env.REPLIT_DEV_DOMAIN;
  const host = domains ?? devDomain ?? req.get("host") ?? "localhost";
  return `https://${host}/api/auth/google/callback`;
}

router.post("/auth/signup", async (req: Request, res: Response) => {
  const parsed = credentialsSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({
      error: "Invalid input",
      details: parsed.error.issues.map((i) => i.message),
    });
    return;
  }
  const { email, password } = parsed.data;

  try {
    const existing = await db
      .select({ id: usersTable.id })
      .from(usersTable)
      .where(eq(usersTable.email, email))
      .limit(1);
    if (existing.length > 0) {
      res.status(409).json({ error: "An account with that email already exists." });
      return;
    }

    const passwordHash = await hashPassword(password);
    const recoveryCode = generateRecoveryCode();
    const recoveryCodeHash = await hashPassword(normalizeRecoveryCode(recoveryCode));

    const [created] = await db
      .insert(usersTable)
      .values({ email, passwordHash, recoveryCodeHash })
      .returning();

    if (!created) {
      res.status(500).json({ error: "Could not create account." });
      return;
    }

    req.session.userId = created.id;
    req.session.save((err) => {
      if (err) {
        req.log.error({ err }, "session save failed on signup");
        res.status(500).json({ error: "Session error" });
        return;
      }
      res.status(201).json({ user: publicUser(created), recoveryCode });
    });
  } catch (err) {
    req.log.error({ err }, "signup failed");
    res.status(500).json({ error: "Signup failed" });
  }
});

router.post("/auth/login", async (req: Request, res: Response) => {
  const parsed = credentialsSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid email or password" });
    return;
  }
  const { email, password } = parsed.data;

  try {
    const [user] = await db
      .select()
      .from(usersTable)
      .where(eq(usersTable.email, email))
      .limit(1);

    if (!user || !user.passwordHash) {
      res.status(401).json({ error: "Invalid email or password" });
      return;
    }

    const ok = await verifyPassword(password, user.passwordHash);
    if (!ok) {
      res.status(401).json({ error: "Invalid email or password" });
      return;
    }

    req.session.userId = user.id;
    req.session.save((err) => {
      if (err) {
        req.log.error({ err }, "session save failed on login");
        res.status(500).json({ error: "Session error" });
        return;
      }
      res.json({ user: publicUser(user) });
    });
  } catch (err) {
    req.log.error({ err }, "login failed");
    res.status(500).json({ error: "Login failed" });
  }
});

router.post("/auth/reset-password", async (req: Request, res: Response) => {
  const parsed = resetSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({
      error: "Invalid input",
      details: parsed.error.issues.map((i) => i.message),
    });
    return;
  }
  const { email, recoveryCode, newPassword } = parsed.data;
  const normalized = normalizeRecoveryCode(recoveryCode);

  try {
    const [user] = await db
      .select()
      .from(usersTable)
      .where(eq(usersTable.email, email))
      .limit(1);

    if (!user || !user.recoveryCodeHash) {
      res.status(401).json({ error: "Invalid email or recovery code." });
      return;
    }

    const ok = await verifyPassword(normalized, user.recoveryCodeHash);
    if (!ok) {
      res.status(401).json({ error: "Invalid email or recovery code." });
      return;
    }

    const newPasswordHash = await hashPassword(newPassword);
    const newRecoveryCode = generateRecoveryCode();
    const newRecoveryCodeHash = await hashPassword(normalizeRecoveryCode(newRecoveryCode));

    const [updated] = await db
      .update(usersTable)
      .set({ passwordHash: newPasswordHash, recoveryCodeHash: newRecoveryCodeHash })
      .where(eq(usersTable.id, user.id))
      .returning();

    if (!updated) {
      res.status(500).json({ error: "Could not reset password." });
      return;
    }

    req.session.userId = updated.id;
    req.session.save((err) => {
      if (err) {
        req.log.error({ err }, "session save failed on reset");
        res.status(500).json({ error: "Session error" });
        return;
      }
      res.json({ user: publicUser(updated), recoveryCode: newRecoveryCode });
    });
  } catch (err) {
    req.log.error({ err }, "reset-password failed");
    res.status(500).json({ error: "Reset failed" });
  }
});

router.post("/auth/logout", (req: Request, res: Response) => {
  req.session.destroy((err) => {
    if (err) {
      req.log.error({ err }, "logout failed");
      res.status(500).json({ error: "Logout failed" });
      return;
    }
    res.clearCookie("infinitesimal.sid");
    res.json({ ok: true });
  });
});

router.get("/auth/me", async (req: Request, res: Response) => {
  if (!req.session?.userId) {
    res.json({ user: null });
    return;
  }
  try {
    const [user] = await db
      .select()
      .from(usersTable)
      .where(eq(usersTable.id, req.session.userId))
      .limit(1);
    if (!user) {
      req.session.destroy(() => {});
      res.json({ user: null });
      return;
    }
    res.json({ user: publicUser(user) });
  } catch (err) {
    req.log.error({ err }, "me failed");
    res.status(500).json({ error: "Could not load user" });
  }
});

// ── Profile update ───────────────────────────────────────────────────────────

const profileSchema = z.object({
  displayName: z.string().trim().max(80).nullable().optional(),
});

router.patch("/auth/profile", async (req: Request, res: Response) => {
  if (!req.session?.userId) {
    res.status(401).json({ error: "Not signed in." });
    return;
  }
  const parsed = profileSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({
      error: "Invalid input",
      details: parsed.error.issues.map((i) => i.message),
    });
    return;
  }
  const { displayName } = parsed.data;

  try {
    const updates: Record<string, string | null> = {};
    if (displayName !== undefined) {
      updates.displayName = displayName?.trim() || null;
    }

    const [updated] = await db
      .update(usersTable)
      .set(updates)
      .where(eq(usersTable.id, req.session.userId))
      .returning();

    if (!updated) {
      res.status(404).json({ error: "User not found." });
      return;
    }

    res.json({ user: publicUser(updated) });
  } catch (err) {
    req.log.error({ err }, "profile update failed");
    res.status(500).json({ error: "Could not update profile." });
  }
});

// ── Google OAuth 2.0 ──────────────────────────────────────────────────────────

router.get("/auth/google", (req: Request, res: Response) => {
  const clientId = process.env.GOOGLE_CLIENT_ID;
  if (!clientId) {
    res.status(503).send("Google sign-in is not configured.");
    return;
  }
  const params = new URLSearchParams({
    client_id: clientId,
    redirect_uri: getCallbackUrl(req),
    response_type: "code",
    scope: "openid email profile",
    access_type: "online",
    prompt: "select_account",
  });
  res.redirect(`https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`);
});

router.get("/auth/google/callback", async (req: Request, res: Response) => {
  const clientId = process.env.GOOGLE_CLIENT_ID;
  const clientSecret = process.env.GOOGLE_CLIENT_SECRET;
  if (!clientId || !clientSecret) {
    res.status(503).send("Google sign-in is not configured.");
    return;
  }

  const code = req.query.code as string | undefined;
  const errorParam = req.query.error as string | undefined;

  if (errorParam || !code) {
    res.redirect("/?auth_error=google_denied");
    return;
  }

  try {
    const callbackUrl = getCallbackUrl(req);

    // Exchange code for tokens
    const tokenRes = await fetch("https://oauth2.googleapis.com/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        code,
        client_id: clientId,
        client_secret: clientSecret,
        redirect_uri: callbackUrl,
        grant_type: "authorization_code",
      }).toString(),
    });

    if (!tokenRes.ok) {
      req.log.error({ status: tokenRes.status }, "google token exchange failed");
      res.redirect("/?auth_error=google_token");
      return;
    }

    const tokenData = (await tokenRes.json()) as { access_token?: string };
    if (!tokenData.access_token) {
      res.redirect("/?auth_error=google_token");
      return;
    }

    // Fetch Google user info
    const userInfoRes = await fetch("https://www.googleapis.com/oauth2/v3/userinfo", {
      headers: { Authorization: `Bearer ${tokenData.access_token}` },
    });

    if (!userInfoRes.ok) {
      req.log.error({ status: userInfoRes.status }, "google userinfo failed");
      res.redirect("/?auth_error=google_userinfo");
      return;
    }

    const googleUser = (await userInfoRes.json()) as {
      sub?: string;
      email?: string;
      name?: string;
      picture?: string;
    };

    if (!googleUser.sub || !googleUser.email) {
      res.redirect("/?auth_error=google_userinfo");
      return;
    }

    const googleId = googleUser.sub;
    const email = googleUser.email.toLowerCase();
    const displayName = googleUser.name ?? null;
    const avatarUrl = googleUser.picture ?? null;

    // Find or create user
    const [existingByGoogleId] = await db
      .select()
      .from(usersTable)
      .where(eq(usersTable.googleId, googleId))
      .limit(1);

    let userId: string;

    if (existingByGoogleId) {
      // Update display info in case it changed
      await db
        .update(usersTable)
        .set({ displayName, avatarUrl })
        .where(eq(usersTable.id, existingByGoogleId.id));
      userId = existingByGoogleId.id;
    } else {
      // Try to find by email (link existing email/password account)
      const [existingByEmail] = await db
        .select()
        .from(usersTable)
        .where(eq(usersTable.email, email))
        .limit(1);

      if (existingByEmail) {
        await db
          .update(usersTable)
          .set({ googleId, displayName, avatarUrl })
          .where(eq(usersTable.id, existingByEmail.id));
        userId = existingByEmail.id;
      } else {
        // Create new Google-only account
        const [created] = await db
          .insert(usersTable)
          .values({ email, googleId, displayName, avatarUrl })
          .returning({ id: usersTable.id });
        if (!created) {
          res.redirect("/?auth_error=google_create");
          return;
        }
        userId = created.id;
      }
    }

    req.session.userId = userId;
    req.session.save((err) => {
      if (err) {
        req.log.error({ err }, "session save failed on google login");
        res.redirect("/?auth_error=session");
        return;
      }
      res.redirect("/");
    });
  } catch (err) {
    req.log.error({ err }, "google oauth callback failed");
    res.redirect("/?auth_error=google_unknown");
  }
});

export default router;
