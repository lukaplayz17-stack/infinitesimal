import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowLeft,
  ArrowRight,
  RotateCw,
  X,
  Home,
  Search,
  Lock,
  Star,
  Globe,
  Loader2,
  Sparkles,
  Shield,
  AlertOctagon,
  LogIn,
  Settings2,
  Check,
  ExternalLink,
  Eye,
  EyeOff,
  KeyRound,
  Server,
  LogOut,
  UserRound,
} from "lucide-react";
import {
  CLOAK_PRESETS,
  applyFavicon,
  applyTitle,
  googleFaviconUrl,
  openInAboutBlank,
  openInBlob,
} from "./lib/cloak";

const PAGE_PATH = "/api/proxy/page";

interface Bookmark {
  url: string;
  label: string;
}

type SearchEngineId = "google" | "duckduckgo" | "brave";
type ProxyBackendId = "direct" | "allorigins" | "corsproxy";

interface SearchEngine {
  id: SearchEngineId;
  label: string;
  searchUrl: (q: string) => string;
  homepage: string;
  faviconDomain: string;
}

const SEARCH_ENGINES: Record<SearchEngineId, SearchEngine> = {
  google: {
    id: "google",
    label: "Google",
    searchUrl: (q) => `https://www.google.com/search?q=${encodeURIComponent(q)}`,
    homepage: "https://www.google.com/",
    faviconDomain: "google.com",
  },
  duckduckgo: {
    id: "duckduckgo",
    label: "DuckDuckGo",
    searchUrl: (q) => `https://duckduckgo.com/html/?q=${encodeURIComponent(q)}`,
    homepage: "https://duckduckgo.com/",
    faviconDomain: "duckduckgo.com",
  },
  brave: {
    id: "brave",
    label: "Brave",
    searchUrl: (q) => `https://search.brave.com/search?q=${encodeURIComponent(q)}`,
    homepage: "https://search.brave.com/",
    faviconDomain: "search.brave.com",
  },
};

interface ProxyBackendInfo {
  id: ProxyBackendId;
  label: string;
  description: string;
}

const PROXY_BACKENDS: Record<ProxyBackendId, ProxyBackendInfo> = {
  direct: {
    id: "direct",
    label: "Direct",
    description: "Server fetches the page directly. Fastest, best for most sites.",
  },
  allorigins: {
    id: "allorigins",
    label: "AllOrigins",
    description: "Routes through api.allorigins.win. Useful when sites block our IP.",
  },
  corsproxy: {
    id: "corsproxy",
    label: "CORS Proxy",
    description: "Routes through corsproxy.io. Alternate fallback.",
  },
};

interface CloakSettings {
  presetId: string;
  title: string;
  faviconDomain: string;
  panicUrl: string;
  panicKey: string;
  lockEnabled: boolean;
  lockPasswordHash: string;
  lockRecoveryHash: string;
  searchEngine: SearchEngineId;
  proxyBackend: ProxyBackendId;
}

const DEFAULT_CLOAK: CloakSettings = {
  presetId: "default",
  title: "Infinitesimal",
  faviconDomain: "",
  panicUrl: "https://classroom.google.com/",
  panicKey: "`",
  lockEnabled: false,
  lockPasswordHash: "",
  lockRecoveryHash: "",
  searchEngine: "google",
  proxyBackend: "direct",
};

const QUICK_LINKS: Bookmark[] = [
  { url: "https://youtube.com/", label: "Youtube" },
  { url: "https://tiktok.com", label: "TikTok" },
  { url: "https://news.ycombinator.com/", label: "Hacker News" },
  { url: "https://www.reddit.com/", label: "Reddit" },
  { url: "https://github.com/trending", label: "GitHub Trending" },
  { url: "https://www.bbc.com/news", label: "BBC News" },
  { url: "https://www.nytimes.com/", label: "NY Times" },
  { url: "https://www.theverge.com/", label: "The Verge" },
];

// --- Prefetch helpers ---
const _prefetching = new Set<string>();

function prefetchProxyUrl(url: string, backend: ProxyBackendId): void {
  const src = buildProxySrc(url, backend);
  if (_prefetching.has(src)) return;
  _prefetching.add(src);
  fetch(src)
    .catch(() => {})
    .finally(() => _prefetching.delete(src));
}

function isLikelyUrl(input: string): boolean {
  if (/^[a-z][a-z0-9+.-]*:\/\//i.test(input)) return true;
  if (/^[a-z0-9-]+(\.[a-z0-9-]+)+(\/.*)?$/i.test(input)) return true;
  return false;
}

function normalizeInputToUrl(input: string, engineId: SearchEngineId): string {
  const trimmed = input.trim();
  if (!trimmed) return "";
  if (isLikelyUrl(trimmed)) {
    if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(trimmed)) {
      return `https://${trimmed}`;
    }
    return trimmed;
  }
  return SEARCH_ENGINES[engineId].searchUrl(trimmed);
}

function hostnameOf(url: string): string {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return url;
  }
}

function isHttps(url: string): boolean {
  try {
    return new URL(url).protocol === "https:";
  } catch {
    return false;
  }
}

function buildProxySrc(url: string, backend: ProxyBackendId): string {
  const params = new URLSearchParams({ url });
  if (backend !== "direct") params.set("backend", backend);
  return `${PAGE_PATH}?${params.toString()}`;
}

async function hashPassword(pw: string): Promise<string> {
  const data = new TextEncoder().encode(pw);
  const buf = await crypto.subtle.digest("SHA-256", data);
  return Array.from(new Uint8Array(buf))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

function generateLockRecoveryCode(): string {
  // 8 bytes = 16 hex chars = 64 bits of entropy. Group as 4-4-4-4.
  const bytes = new Uint8Array(8);
  crypto.getRandomValues(bytes);
  const hex = Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("")
    .toUpperCase();
  return `${hex.slice(0, 4)}-${hex.slice(4, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}`;
}

function normalizeRecoveryCode(input: string): string {
  return input.replace(/[^A-Za-z0-9]/g, "").toUpperCase();
}

interface HistoryState {
  stack: string[];
  index: number;
}

interface AuthUser {
  id: string;
  email: string;
  displayName: string | null;
  avatarUrl: string | null;
  createdAt: string;
}

async function apiFetch(path: string, init?: RequestInit): Promise<Response> {
  return fetch(path, {
    ...init,
    credentials: "include",
    headers: {
      ...(init?.body ? { "Content-Type": "application/json" } : {}),
      ...(init?.headers ?? {}),
    },
  });
}

function App() {
  const [history, setHistory] = useState<HistoryState>({ stack: [], index: -1 });
  const [inputValue, setInputValue] = useState("");
  const [loading, setLoading] = useState(false);
  const [iframeKey, setIframeKey] = useState(0);
  const [bookmarks, setBookmarks] = useState<Bookmark[]>(() => {
    try {
      const raw = localStorage.getItem("proxy.bookmarks");
      if (raw) return JSON.parse(raw) as Bookmark[];
    } catch {}
    return [];
  });
  const [cloak, setCloak] = useState<CloakSettings>(() => {
    try {
      const raw = localStorage.getItem("proxy.cloak");
      if (raw) return { ...DEFAULT_CLOAK, ...(JSON.parse(raw) as Partial<CloakSettings>) };
    } catch {}
    return DEFAULT_CLOAK;
  });
  const [showSettings, setShowSettings] = useState(false);
  const [showLogin, setShowLogin] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const [googleAuthError, setGoogleAuthError] = useState<string | null>(null);
  const [currentUser, setCurrentUser] = useState<AuthUser | null>(null);
  const [authLoaded, setAuthLoaded] = useState(false);
  const [locked, setLocked] = useState<boolean>(() => {
    try {
      const raw = localStorage.getItem("proxy.cloak");
      if (raw) {
        const c = JSON.parse(raw) as Partial<CloakSettings>;
        return !!c.lockEnabled;
      }
    } catch {}
    return false;
  });

  const inputRef = useRef<HTMLInputElement>(null);
  const iframeRef = useRef<HTMLIFrameElement>(null);

  const currentUrl = history.index >= 0 ? history.stack[history.index] : null;
  const canBack = history.index > 0;
  const canForward = history.index >= 0 && history.index < history.stack.length - 1;

  // Persist + apply cloak
  useEffect(() => {
    try {
      localStorage.setItem("proxy.cloak", JSON.stringify(cloak));
    } catch {}
    applyTitle(cloak.title);
    applyFavicon(cloak.faviconDomain ? googleFaviconUrl(cloak.faviconDomain) : "/favicon.svg");
  }, [cloak]);

  useEffect(() => {
    try {
      localStorage.setItem("proxy.bookmarks", JSON.stringify(bookmarks));
    } catch {}
  }, [bookmarks]);

  useEffect(() => {
    if (currentUrl) {
      setInputValue(currentUrl);
    } else {
      setInputValue("");
    }
  }, [currentUrl]);

  // Detect Google OAuth error redirect (?auth_error=...)
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const err = params.get("auth_error");
    if (err) {
      setGoogleAuthError(
        err === "google_denied"
          ? "Google sign-in was cancelled."
          : "Google sign-in failed. Please try again.",
      );
      setShowLogin(true);
      // Remove the query param without triggering a navigation
      const clean = window.location.pathname;
      window.history.replaceState({}, "", clean);
    }
  }, []);

  // Hydrate current user on mount
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res = await apiFetch("/api/auth/me");
        if (!res.ok) return;
        const data = (await res.json()) as { user: AuthUser | null };
        if (!cancelled) setCurrentUser(data.user);
      } catch {
        // ignore - offline or server down; user stays signed out
      } finally {
        if (!cancelled) setAuthLoaded(true);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const handleLogout = useCallback(async () => {
    try {
      await apiFetch("/api/auth/logout", { method: "POST" });
    } catch {
      // ignore network errors; clear locally anyway
    }
    setCurrentUser(null);
  }, []);

  const navigate = useCallback(
    (rawInput: string) => {
      const url = normalizeInputToUrl(rawInput, cloak.searchEngine);
      if (!url) return;
      setLoading(true);
      setHistory((prev) => {
        const truncated = prev.stack.slice(0, prev.index + 1);
        if (truncated[truncated.length - 1] === url) {
          return prev;
        }
        const nextStack = [...truncated, url];
        return { stack: nextStack, index: nextStack.length - 1 };
      });
    },
    [cloak.searchEngine],
  );

  const goBack = useCallback(() => {
    setHistory((prev) => {
      if (prev.index <= 0) return prev;
      setLoading(true);
      return { ...prev, index: prev.index - 1 };
    });
  }, []);

  const goForward = useCallback(() => {
    setHistory((prev) => {
      if (prev.index >= prev.stack.length - 1) return prev;
      setLoading(true);
      return { ...prev, index: prev.index + 1 };
    });
  }, []);

  const reload = useCallback(() => {
    if (!currentUrl) return;
    setLoading(true);
    setIframeKey((k) => k + 1);
  }, [currentUrl]);

  const stopLoading = useCallback(() => {
    setLoading(false);
    if (iframeRef.current) {
      try {
        iframeRef.current.contentWindow?.stop?.();
      } catch {}
    }
  }, []);

  const goHome = useCallback(() => {
    setHistory({ stack: [], index: -1 });
    setInputValue("");
    setLoading(false);
    setTimeout(() => inputRef.current?.focus(), 0);
  }, []);

  const triggerPanic = useCallback(() => {
    const url = cloak.panicUrl || "https://www.google.com/";
    try {
      window.location.replace(url);
    } catch {
      window.location.href = url;
    }
  }, [cloak.panicUrl]);

  // Cross-iframe navigation messages
  useEffect(() => {
    function onMessage(ev: MessageEvent) {
      if (!ev.data || typeof ev.data !== "object") return;
      const data = ev.data as { __proxyNav?: boolean; url?: string };
      if (data.__proxyNav && typeof data.url === "string") {
        navigate(data.url);
      }
    }
    window.addEventListener("message", onMessage);
    return () => window.removeEventListener("message", onMessage);
  }, [navigate]);

  // Keyboard shortcuts
  useEffect(() => {
    function onKey(ev: KeyboardEvent) {
      const isCmd = ev.metaKey || ev.ctrlKey;
      const target = ev.target as HTMLElement | null;
      const inField =
        target &&
        (target.tagName === "INPUT" ||
          target.tagName === "TEXTAREA" ||
          (target as HTMLElement).isContentEditable);

      // Panic key - works even in inputs (only if it isn't a printable typing target)
      if (
        cloak.panicKey &&
        ev.key === cloak.panicKey &&
        !ev.ctrlKey &&
        !ev.metaKey &&
        !ev.altKey &&
        !inField
      ) {
        ev.preventDefault();
        triggerPanic();
        return;
      }

      if (isCmd && ev.key.toLowerCase() === "l") {
        ev.preventDefault();
        inputRef.current?.focus();
        inputRef.current?.select();
      } else if (isCmd && ev.key.toLowerCase() === "r") {
        ev.preventDefault();
        reload();
      } else if (ev.key === "Escape" && document.activeElement === inputRef.current) {
        inputRef.current?.blur();
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [reload, triggerPanic, cloak.panicKey]);

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim()) return;
    navigate(inputValue);
    inputRef.current?.blur();
  };

  const isBookmarked = useMemo(() => {
    if (!currentUrl) return false;
    return bookmarks.some((b) => b.url === currentUrl);
  }, [bookmarks, currentUrl]);

  const toggleBookmark = useCallback(() => {
    if (!currentUrl) return;
    setBookmarks((prev) => {
      const exists = prev.find((b) => b.url === currentUrl);
      if (exists) return prev.filter((b) => b.url !== currentUrl);
      return [{ url: currentUrl, label: hostnameOf(currentUrl) }, ...prev].slice(0, 24);
    });
  }, [currentUrl]);

  const iframeSrc = currentUrl ? buildProxySrc(currentUrl, cloak.proxyBackend) : null;

  if (locked && cloak.lockEnabled && cloak.lockPasswordHash) {
    return (
      <LockScreen
        cloak={cloak}
        onUnlock={() => setLocked(false)}
        onResetLock={() =>
          setCloak({
            ...cloak,
            lockEnabled: false,
            lockPasswordHash: "",
            lockRecoveryHash: "",
          })
        }
        onPanic={triggerPanic}
      />
    );
  }

  return (
    <div className="flex h-full w-full flex-col bg-[#0b0b10] text-[#e7e7ee]">
      <Toolbar
        canBack={canBack}
        canForward={canForward}
        loading={loading}
        currentUrl={currentUrl}
        inputValue={inputValue}
        setInputValue={setInputValue}
        inputRef={inputRef}
        onSubmit={onSubmit}
        onBack={goBack}
        onForward={goForward}
        onReload={reload}
        onStop={stopLoading}
        onHome={goHome}
        isBookmarked={isBookmarked}
        onToggleBookmark={toggleBookmark}
        onPanic={triggerPanic}
        onOpenSettings={() => setShowSettings(true)}
        onOpenLogin={() => setShowLogin(true)}
        onOpenProfile={() => setShowProfile(true)}
        currentUser={currentUser}
        authLoaded={authLoaded}
        onLogout={handleLogout}
        lockEnabled={cloak.lockEnabled && !!cloak.lockPasswordHash}
        onLock={() => setLocked(true)}
      />

      <div className="relative flex-1 overflow-hidden bg-white">
        {iframeSrc ? (
          <>
            <iframe
              ref={iframeRef}
              key={iframeKey + ":" + iframeSrc}
              src={iframeSrc}
              className="h-full w-full border-0 bg-white"
              sandbox="allow-forms allow-scripts allow-popups allow-same-origin allow-modals"
              referrerPolicy="no-referrer"
              onLoad={() => setLoading(false)}
              title="Proxied page"
            />
            {loading && (
              <div className="pointer-events-none absolute inset-x-0 top-0 h-0.5 overflow-hidden bg-transparent">
                <div className="loader-bar h-full w-1/3 rounded-r-full bg-gradient-to-r from-violet-500 via-fuchsia-400 to-violet-500" />
              </div>
            )}
          </>
        ) : (
          <NewTab
            bookmarks={bookmarks}
            backend={cloak.proxyBackend}
            onPick={(url) => navigate(url)}
            onRemoveBookmark={(url) =>
              setBookmarks((prev) => prev.filter((b) => b.url !== url))
            }
            onAboutBlank={() => openInAboutBlank()}
            onBlob={() => openInBlob()}
          />
        )}
      </div>

      {showSettings && (
        <SettingsModal
          cloak={cloak}
          setCloak={setCloak}
          onClose={() => setShowSettings(false)}
        />
      )}
      {showLogin && (
        <LoginModal
          onClose={() => {
            setShowLogin(false);
            setGoogleAuthError(null);
          }}
          onAuthed={(user) => {
            setCurrentUser(user);
            setShowLogin(false);
            setGoogleAuthError(null);
          }}
          googleAuthError={googleAuthError}
        />
      )}
      {showProfile && currentUser && (
        <ProfileModal
          user={currentUser}
          onClose={() => setShowProfile(false)}
          onUpdated={(user) => setCurrentUser(user)}
        />
      )}

      <style>{`
        .loader-bar {
          animation: loaderSlide 1.1s cubic-bezier(.4,.0,.2,1) infinite;
        }
        @keyframes loaderSlide {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(400%); }
        }
      `}</style>
    </div>
  );
}

interface ToolbarProps {
  canBack: boolean;
  canForward: boolean;
  loading: boolean;
  currentUrl: string | null;
  inputValue: string;
  setInputValue: (v: string) => void;
  inputRef: React.RefObject<HTMLInputElement | null>;
  onSubmit: (e: React.FormEvent) => void;
  onBack: () => void;
  onForward: () => void;
  onReload: () => void;
  onStop: () => void;
  onHome: () => void;
  isBookmarked: boolean;
  onToggleBookmark: () => void;
  onPanic: () => void;
  onOpenSettings: () => void;
  onOpenLogin: () => void;
  currentUser: AuthUser | null;
  authLoaded: boolean;
  onLogout: () => void;
  onOpenProfile: () => void;
  lockEnabled: boolean;
  onLock: () => void;
}

function Toolbar(props: ToolbarProps) {
  const {
    canBack,
    canForward,
    loading,
    currentUrl,
    inputValue,
    setInputValue,
    inputRef,
    onSubmit,
    onBack,
    onForward,
    onReload,
    onStop,
    onHome,
    isBookmarked,
    onToggleBookmark,
    onPanic,
    onOpenSettings,
    onOpenLogin,
    currentUser,
    authLoaded,
    onLogout,
    onOpenProfile,
    lockEnabled,
    onLock,
  } = props;

  const secure = currentUrl ? isHttps(currentUrl) : false;

  return (
    <div className="flex items-center gap-1.5 border-b border-[#1f1f2a] bg-[#0f0f17]/95 px-3 py-2.5 backdrop-blur supports-[backdrop-filter]:bg-[#0f0f17]/80">
      <NavButton onClick={onBack} disabled={!canBack} ariaLabel="Back">
        <ArrowLeft size={16} strokeWidth={2.25} />
      </NavButton>
      <NavButton onClick={onForward} disabled={!canForward} ariaLabel="Forward">
        <ArrowRight size={16} strokeWidth={2.25} />
      </NavButton>
      <NavButton
        onClick={loading ? onStop : onReload}
        disabled={!currentUrl && !loading}
        ariaLabel={loading ? "Stop" : "Reload"}
      >
        {loading ? <X size={16} strokeWidth={2.25} /> : <RotateCw size={16} strokeWidth={2.25} />}
      </NavButton>
      <NavButton onClick={onHome} disabled={false} ariaLabel="New tab">
        <Home size={16} strokeWidth={2.25} />
      </NavButton>

      <form onSubmit={onSubmit} className="flex flex-1 items-center">
        <div className="group flex h-9 flex-1 items-center gap-2 rounded-full border border-[#23232f] bg-[#15151d] px-3.5 text-sm transition-colors focus-within:border-violet-500/60 focus-within:bg-[#181821] focus-within:shadow-[0_0_0_3px_rgba(139,92,246,0.12)]">
          <div className="flex items-center text-[#7f7f8c]">
            {currentUrl ? (
              secure ? (
                <Lock size={13} className="text-emerald-400" />
              ) : (
                <Globe size={13} />
              )
            ) : (
              <Search size={13} />
            )}
          </div>
          <input
            ref={inputRef}
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onFocus={(e) => e.currentTarget.select()}
            spellCheck={false}
            autoComplete="off"
            autoCorrect="off"
            placeholder="Search the web or enter a URL"
            className="flex-1 bg-transparent text-[13.5px] text-[#e7e7ee] placeholder:text-[#5b5b6b] focus:outline-none"
          />
          {loading && <Loader2 size={13} className="animate-spin text-[#7f7f8c]" />}
        </div>
      </form>

      <NavButton
        onClick={onToggleBookmark}
        disabled={!currentUrl}
        ariaLabel={isBookmarked ? "Remove bookmark" : "Add bookmark"}
      >
        <Star
          size={16}
          strokeWidth={2.25}
          className={isBookmarked ? "fill-amber-400 text-amber-400" : ""}
        />
      </NavButton>

      <div className="mx-1 h-5 w-px bg-[#23232f]" />

      {authLoaded && currentUser ? (
        <div className="flex items-center gap-1">
          <button
            onClick={onOpenProfile}
            title={`${currentUser.displayName ?? currentUser.email} — click to edit profile`}
            className="hidden h-8 max-w-[180px] cursor-pointer items-center gap-1.5 rounded-full border border-[#23232f] bg-[#15151d] px-2 text-[12px] text-[#c2c2cc] transition-colors hover:border-violet-500/40 hover:text-white sm:flex"
          >
            {currentUser.avatarUrl ? (
              <img
                src={currentUser.avatarUrl}
                alt="Avatar"
                className="h-5 w-5 rounded-full object-cover"
              />
            ) : (
              <UserRound size={12} className="text-violet-300" />
            )}
            <span className="truncate">
              {currentUser.displayName ?? currentUser.email}
            </span>
          </button>
          <NavButton onClick={onLogout} disabled={false} ariaLabel="Sign out">
            <LogOut size={16} strokeWidth={2.25} />
          </NavButton>
        </div>
      ) : (
        <NavButton onClick={onOpenLogin} disabled={false} ariaLabel="Sign in">
          <LogIn size={16} strokeWidth={2.25} />
        </NavButton>
      )}
      {lockEnabled && (
        <NavButton onClick={onLock} disabled={false} ariaLabel="Lock screen">
          <KeyRound size={16} strokeWidth={2.25} />
        </NavButton>
      )}
      <NavButton onClick={onOpenSettings} disabled={false} ariaLabel="Cloak settings">
        <Settings2 size={16} strokeWidth={2.25} />
      </NavButton>
      <button
        type="button"
        onClick={onPanic}
        aria-label="Panic"
        title="Panic"
        className="flex h-8 items-center gap-1.5 rounded-full bg-rose-600/90 px-3 text-[12px] font-semibold text-white shadow-[0_2px_10px_-2px_rgba(244,63,94,0.6)] transition-all hover:bg-rose-500 active:translate-y-px"
      >
        <AlertOctagon size={14} strokeWidth={2.5} />
        Panic
      </button>
    </div>
  );
}

function NavButton({
  children,
  onClick,
  disabled,
  ariaLabel,
}: {
  children: React.ReactNode;
  onClick: () => void;
  disabled: boolean;
  ariaLabel: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      aria-label={ariaLabel}
      title={ariaLabel}
      className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-[#c2c2cc] transition-all hover:bg-[#1c1c27] hover:text-white disabled:cursor-not-allowed disabled:text-[#3a3a48] disabled:hover:bg-transparent"
    >
      {children}
    </button>
  );
}

function ShortcutTile({
  label,
  url,
  onPick,
  onRemove,
  onPrefetch,
}: {
  label: string;
  url: string;
  onPick: () => void;
  onRemove?: () => void;
  onPrefetch?: () => void;
}) {
  const domain = hostnameOf(url);
  const [imgOk, setImgOk] = useState(true);
  const initials = (domain.split(".")[0] ?? "?").slice(0, 2).toUpperCase();

  return (
    <div className="group relative flex flex-col items-center gap-1.5">
      <button
        onClick={onPick}
        onMouseEnter={onPrefetch}
        className="relative flex h-14 w-14 items-center justify-center rounded-2xl border border-[#23232f] bg-[#15151d] transition-all hover:border-violet-500/30 hover:bg-[#1c1c2a] hover:shadow-[0_4px_20px_-4px_rgba(139,92,246,0.25)]"
      >
        {imgOk ? (
          <img
            src={`https://www.google.com/s2/favicons?domain=${domain}&sz=64`}
            alt={label}
            onError={() => setImgOk(false)}
            className="h-8 w-8 object-contain"
          />
        ) : (
          <span className="text-[13px] font-semibold text-violet-300">{initials}</span>
        )}
      </button>
      <span className="w-16 truncate text-center text-[11px] text-[#6b6b78] group-hover:text-[#a2a2b0]">
        {label}
      </span>
      {onRemove && (
        <button
          onClick={(e) => {
            e.stopPropagation();
            onRemove();
          }}
          className="absolute -right-1 -top-1 flex h-5 w-5 items-center justify-center rounded-full bg-[#2a2a38] text-[#7f7f8c] opacity-0 transition-opacity hover:bg-rose-500/20 hover:text-rose-300 group-hover:opacity-100"
          aria-label="Remove bookmark"
        >
          <X size={10} />
        </button>
      )}
    </div>
  );
}

function NewTab({
  bookmarks,
  backend,
  onPick,
  onRemoveBookmark,
  onAboutBlank,
  onBlob,
}: {
  bookmarks: Bookmark[];
  backend: ProxyBackendId;
  onPick: (url: string) => void;
  onRemoveBookmark: (url: string) => void;
  onAboutBlank: () => void;
  onBlob: () => void;
}) {
  const [query, setQuery] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  const prefetchTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;
    onPick(query);
  };

  const handleQueryChange = (val: string) => {
    setQuery(val);
    if (prefetchTimer.current) clearTimeout(prefetchTimer.current);
    prefetchTimer.current = setTimeout(() => {
      const trimmed = val.trim();
      if (trimmed && isLikelyUrl(trimmed)) {
        prefetchProxyUrl(trimmed, backend);
      }
    }, 400);
  };

  return (
    <div className="relative h-full w-full overflow-auto bg-[#0b0b10] text-[#e7e7ee]">
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 left-1/2 h-[600px] w-[600px] -translate-x-1/2 rounded-full bg-violet-600/15 blur-[140px]" />
        <div className="absolute bottom-0 left-1/4 h-[300px] w-[400px] rounded-full bg-fuchsia-600/10 blur-[120px]" />
      </div>

      <div className="relative mx-auto flex min-h-full max-w-2xl flex-col items-center px-6 pb-16 pt-[10vh]">

        {/* Wordmark */}
        <div className="mb-1 flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-violet-500 to-fuchsia-500 shadow-[0_0_28px_rgba(139,92,246,0.45)]">
            <Sparkles size={20} className="text-white" />
          </div>
          <span className="text-[24px] font-semibold tracking-tight text-white">
            Infinitesimal
          </span>
        </div>
        <p className="mb-9 mt-1 text-[13px] text-[#5b5b6b]">
          Private gateway to the web
        </p>

        {/* Search bar */}
        <form onSubmit={submit} className="w-full max-w-xl">
          <div className="flex h-[52px] w-full items-center gap-3 rounded-2xl border border-[#2a2a38] bg-[#13131c] px-5 shadow-[0_4px_30px_-8px_rgba(0,0,0,0.5)] transition-all focus-within:border-violet-500/50 focus-within:shadow-[0_4px_32px_-6px_rgba(139,92,246,0.22)]">
            <Search size={17} className="shrink-0 text-[#4b4b5b]" />
            <input
              ref={inputRef}
              value={query}
              onChange={(e) => handleQueryChange(e.target.value)}
              placeholder="Search the web or enter a URL"
              className="flex-1 bg-transparent text-[15px] text-[#e7e7ee] placeholder:text-[#3d3d4d] focus:outline-none"
              spellCheck={false}
              autoComplete="off"
              autoCorrect="off"
            />
            {query && (
              <button
                type="button"
                onClick={() => setQuery("")}
                className="shrink-0 text-[#4b4b5b] hover:text-[#a2a2b0]"
              >
                <X size={14} />
              </button>
            )}
            <button
              type="submit"
              className="h-8 shrink-0 rounded-xl bg-gradient-to-b from-violet-500 to-violet-600 px-4 text-[13px] font-medium text-white shadow-[0_2px_10px_-2px_rgba(139,92,246,0.5)] hover:from-violet-400 hover:to-violet-500"
            >
              Search
            </button>
          </div>
        </form>

        {/* Cloak launchers — subtle */}
        <div className="mt-4 flex items-center gap-3">
          <button
            onClick={onAboutBlank}
            className="flex items-center gap-1.5 rounded-full border border-[#1d1d27] px-3 py-1 text-[11px] text-[#4b4b5b] transition-colors hover:border-[#2d2d3a] hover:text-[#8a8a99]"
          >
            <Eye size={11} />
            about:blank
          </button>
          <button
            onClick={onBlob}
            className="flex items-center gap-1.5 rounded-full border border-[#1d1d27] px-3 py-1 text-[11px] text-[#4b4b5b] transition-colors hover:border-[#2d2d3a] hover:text-[#8a8a99]"
          >
            <EyeOff size={11} />
            blob:
          </button>
        </div>

        {/* Bookmarks */}
        {bookmarks.length > 0 && (
          <div className="mt-12 w-full">
            <div className="mb-5 text-center text-[10px] font-semibold uppercase tracking-[0.18em] text-[#4b4b5b]">
              Bookmarks
            </div>
            <div className="flex flex-wrap justify-center gap-5">
              {bookmarks.map((b) => (
                <ShortcutTile
                  key={b.url}
                  label={b.label}
                  url={b.url}
                  onPick={() => onPick(b.url)}
                  onRemove={() => onRemoveBookmark(b.url)}
                  onPrefetch={() => prefetchProxyUrl(b.url, backend)}
                />
              ))}
            </div>
          </div>
        )}

        {/* Quick links */}
        <div className="mt-12 w-full">
          <div className="mb-5 text-center text-[10px] font-semibold uppercase tracking-[0.18em] text-[#4b4b5b]">
            Quick links
          </div>
          <div className="flex flex-wrap justify-center gap-5">
            {QUICK_LINKS.map((b) => (
              <ShortcutTile
                key={b.url}
                label={b.label}
                url={b.url}
                onPick={() => onPick(b.url)}
                onPrefetch={() => prefetchProxyUrl(b.url, backend)}
              />
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="mt-16 flex items-center gap-3 text-[11px] text-[#3d3d4d]">
          <a href="/privacy" className="hover:text-[#6b6b78]">
            Privacy Policy
          </a>
          <span>·</span>
          <span>© {new Date().getFullYear()} Infinitesimal</span>
        </div>
      </div>
    </div>
  );
}

function CloakLaunchButton({
  children,
  onClick,
  icon,
}: {
  children: React.ReactNode;
  onClick: () => void;
  icon: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      className="flex items-center gap-1.5 rounded-full border border-[#23232f] bg-[#15151d] px-3 py-1.5 text-[12px] font-medium text-[#c2c2cc] transition-all hover:border-violet-500/40 hover:bg-[#181821] hover:text-white"
    >
      <span className="text-violet-300">{icon}</span>
      {children}
      <ExternalLink size={11} className="text-[#6b6b78]" />
    </button>
  );
}

function Section({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <div className="mt-12 w-full">
      <div className="mb-3 flex items-center gap-2 text-[11px] font-medium uppercase tracking-[0.14em] text-[#7f7f8c]">
        <span className="h-px flex-1 bg-[#23232f]" />
        {title}
        <span className="h-px flex-1 bg-[#23232f]" />
      </div>
      {children}
    </div>
  );
}

function Tile({
  label,
  url,
  onPick,
  onRemove,
}: {
  label: string;
  url: string;
  onPick: () => void;
  onRemove?: () => void;
}) {
  const host = hostnameOf(url);
  const initials = host
    .split(".")
    .filter(Boolean)[0]!
    .slice(0, 2)
    .toUpperCase();

  return (
    <div className="group relative">
      <button
        onClick={onPick}
        className="flex w-full items-center gap-3 rounded-xl border border-[#1d1d27] bg-[#13131c] px-3 py-2.5 text-left transition-all hover:border-[#2a2a36] hover:bg-[#181821]"
      >
        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-violet-500/30 to-fuchsia-500/20 text-[11px] font-semibold text-violet-200">
          {initials}
        </div>
        <div className="min-w-0 flex-1">
          <div className="truncate text-[13px] font-medium text-[#e7e7ee]">
            {label}
          </div>
          <div className="truncate text-[11px] text-[#6b6b78]">{host}</div>
        </div>
      </button>
      {onRemove && (
        <button
          onClick={(e) => {
            e.stopPropagation();
            onRemove();
          }}
          className="absolute right-1.5 top-1.5 flex h-5 w-5 items-center justify-center rounded-md bg-[#1c1c27] text-[#7f7f8c] opacity-0 transition-opacity hover:text-white group-hover:opacity-100"
          aria-label="Remove bookmark"
        >
          <X size={11} />
        </button>
      )}
    </div>
  );
}

function ModalShell({
  title,
  icon,
  children,
  onClose,
  width = "max-w-lg",
}: {
  title: string;
  icon: React.ReactNode;
  children: React.ReactNode;
  onClose: () => void;
  width?: string;
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 px-4 backdrop-blur-sm">
      <div
        className={`w-full ${width} overflow-hidden rounded-2xl border border-[#23232f] bg-[#0f0f17] shadow-[0_30px_80px_-20px_rgba(0,0,0,0.8)]`}
      >
        <div className="flex items-center justify-between border-b border-[#1f1f2a] px-5 py-3.5">
          <div className="flex items-center gap-2 text-[14px] font-semibold text-white">
            <span className="text-violet-400">{icon}</span>
            {title}
          </div>
          <button
            onClick={onClose}
            className="flex h-7 w-7 items-center justify-center rounded-full text-[#7f7f8c] transition-colors hover:bg-[#1c1c27] hover:text-white"
            aria-label="Close"
          >
            <X size={14} />
          </button>
        </div>
        <div className="max-h-[80vh] overflow-y-auto px-5 py-4">{children}</div>
      </div>
    </div>
  );
}

function SettingsModal({
  cloak,
  setCloak,
  onClose,
}: {
  cloak: CloakSettings;
  setCloak: (next: CloakSettings) => void;
  onClose: () => void;
}) {
  const [draft, setDraft] = useState<CloakSettings>(cloak);
  const [pw, setPw] = useState("");
  const [savingPw, setSavingPw] = useState(false);
  const [newRecoveryCode, setNewRecoveryCode] = useState<string | null>(null);

  const update = (patch: Partial<CloakSettings>) =>
    setDraft((d) => ({ ...d, ...patch }));

  const applyPreset = (id: string) => {
    const preset = CLOAK_PRESETS.find((p) => p.id === id);
    if (!preset) return;
    update({
      presetId: preset.id,
      title: preset.title,
      faviconDomain: preset.faviconDomain,
    });
  };

  const save = async () => {
    let next = { ...draft };
    let codeToShow: string | null = null;
    if (pw) {
      setSavingPw(true);
      next.lockPasswordHash = await hashPassword(pw);
      next.lockEnabled = true;
      const code = generateLockRecoveryCode();
      next.lockRecoveryHash = await hashPassword(normalizeRecoveryCode(code));
      codeToShow = code;
      setSavingPw(false);
    }
    setCloak(next);
    setDraft(next);
    setPw("");
    if (codeToShow) {
      setNewRecoveryCode(codeToShow);
    } else {
      onClose();
    }
  };

  const clearLock = () => {
    update({ lockEnabled: false, lockPasswordHash: "", lockRecoveryHash: "" });
    setPw("");
  };

  if (newRecoveryCode) {
    return (
      <ModalShell
        title="Lock recovery code"
        icon={<KeyRound size={16} />}
        onClose={onClose}
      >
        <RecoveryCodePanel
          intro="Save this code somewhere safe. If you forget your lock password, you can use it to unlock and remove the lock from this device. It only works once."
          code={newRecoveryCode}
          onDone={() => {
            setNewRecoveryCode(null);
            onClose();
          }}
        />
      </ModalShell>
    );
  }

  return (
    <ModalShell
      title="Cloak & settings"
      icon={<Shield size={16} />}
      onClose={onClose}
    >
      <div className="space-y-5">
        <FieldGroup label="Search engine" hint="Used when you type a query instead of a URL.">
          <div className="grid grid-cols-3 gap-1.5">
            {(Object.values(SEARCH_ENGINES) as SearchEngine[]).map((eng) => {
              const active = draft.searchEngine === eng.id;
              return (
                <button
                  key={eng.id}
                  type="button"
                  onClick={() => update({ searchEngine: eng.id })}
                  className={`flex items-center gap-2 rounded-lg border px-2.5 py-2 text-left text-[12px] transition-colors ${
                    active
                      ? "border-violet-500/60 bg-violet-500/10 text-white"
                      : "border-[#23232f] bg-[#15151d] text-[#c2c2cc] hover:border-[#2a2a36] hover:bg-[#181821]"
                  }`}
                >
                  <img
                    src={googleFaviconUrl(eng.faviconDomain)}
                    alt=""
                    className="h-4 w-4 rounded-sm"
                    referrerPolicy="no-referrer"
                  />
                  <span className="truncate">{eng.label}</span>
                  {active && <Check size={12} className="ml-auto text-violet-300" />}
                </button>
              );
            })}
          </div>
        </FieldGroup>

        <FieldGroup
          label="Proxy backend"
          hint="Which fetch route the server uses to reach the target site."
        >
          <div className="space-y-1.5">
            {(Object.values(PROXY_BACKENDS) as ProxyBackendInfo[]).map((b) => {
              const active = draft.proxyBackend === b.id;
              return (
                <button
                  key={b.id}
                  type="button"
                  onClick={() => update({ proxyBackend: b.id })}
                  className={`flex w-full items-start gap-3 rounded-lg border px-3 py-2.5 text-left transition-colors ${
                    active
                      ? "border-violet-500/60 bg-violet-500/10"
                      : "border-[#23232f] bg-[#15151d] hover:border-[#2a2a36] hover:bg-[#181821]"
                  }`}
                >
                  <div className="mt-0.5 text-violet-300">
                    <Server size={14} />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 text-[13px] font-medium text-white">
                      {b.label}
                      {active && <Check size={12} className="text-violet-300" />}
                    </div>
                    <div className="text-[11px] text-[#8a8a99]">{b.description}</div>
                  </div>
                </button>
              );
            })}
          </div>
        </FieldGroup>

        <FieldGroup label="Tab disguise" hint="Pick a preset, or set a custom title and favicon.">
          <div className="grid grid-cols-2 gap-1.5 sm:grid-cols-3">
            {CLOAK_PRESETS.map((p) => {
              const active = draft.presetId === p.id;
              return (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => applyPreset(p.id)}
                  className={`flex items-center gap-2 rounded-lg border px-2.5 py-2 text-left text-[12px] transition-colors ${
                    active
                      ? "border-violet-500/60 bg-violet-500/10 text-white"
                      : "border-[#23232f] bg-[#15151d] text-[#c2c2cc] hover:border-[#2a2a36] hover:bg-[#181821]"
                  }`}
                >
                  {p.faviconDomain ? (
                    <img
                      src={googleFaviconUrl(p.faviconDomain)}
                      alt=""
                      className="h-4 w-4 rounded-sm"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <div className="h-4 w-4 rounded-sm bg-gradient-to-br from-violet-500/40 to-fuchsia-500/30" />
                  )}
                  <span className="truncate">{p.label}</span>
                  {active && <Check size={12} className="ml-auto text-violet-300" />}
                </button>
              );
            })}
          </div>
        </FieldGroup>

        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Tab title">
            <input
              value={draft.title}
              onChange={(e) => update({ title: e.target.value, presetId: "custom" })}
              className="w-full rounded-lg border border-[#23232f] bg-[#15151d] px-3 py-2 text-[13px] text-white placeholder:text-[#5b5b6b] focus:border-violet-500/60 focus:outline-none"
              placeholder="Untitled document"
            />
          </Field>
          <Field label="Favicon domain" hint="e.g. classroom.google.com">
            <input
              value={draft.faviconDomain}
              onChange={(e) => update({ faviconDomain: e.target.value, presetId: "custom" })}
              className="w-full rounded-lg border border-[#23232f] bg-[#15151d] px-3 py-2 text-[13px] text-white placeholder:text-[#5b5b6b] focus:border-violet-500/60 focus:outline-none"
              placeholder="docs.google.com"
            />
          </Field>
        </div>

        <FieldGroup label="Panic button" hint="Press the panic key or click Panic to instantly leave.">
          <div className="grid gap-3 sm:grid-cols-[1fr_auto]">
            <Field label="Panic redirect URL">
              <input
                value={draft.panicUrl}
                onChange={(e) => update({ panicUrl: e.target.value })}
                className="w-full rounded-lg border border-[#23232f] bg-[#15151d] px-3 py-2 text-[13px] text-white placeholder:text-[#5b5b6b] focus:border-violet-500/60 focus:outline-none"
                placeholder="https://classroom.google.com/"
              />
            </Field>
            <Field label="Panic key">
              <input
                value={draft.panicKey}
                onChange={(e) =>
                  update({ panicKey: e.target.value.slice(0, 1) })
                }
                maxLength={1}
                className="w-20 rounded-lg border border-[#23232f] bg-[#15151d] px-3 py-2 text-center text-[13px] text-white placeholder:text-[#5b5b6b] focus:border-violet-500/60 focus:outline-none"
                placeholder="`"
              />
            </Field>
          </div>
        </FieldGroup>

        <FieldGroup
          label="Password lock"
          hint="When enabled, a fake login screen guards the app. Click the key icon in the toolbar to lock."
        >
          {draft.lockEnabled && draft.lockPasswordHash ? (
            <div className="flex items-center justify-between rounded-lg border border-emerald-500/20 bg-emerald-500/5 px-3 py-2.5 text-[12px] text-emerald-200">
              <div className="flex items-center gap-2">
                <Check size={14} /> Lock is set.
              </div>
              <button
                onClick={clearLock}
                className="rounded-md border border-emerald-500/30 px-2 py-1 text-[11px] text-emerald-100 hover:bg-emerald-500/10"
              >
                Remove
              </button>
            </div>
          ) : (
            <input
              type="password"
              value={pw}
              onChange={(e) => setPw(e.target.value)}
              placeholder="Set a password"
              className="w-full rounded-lg border border-[#23232f] bg-[#15151d] px-3 py-2 text-[13px] text-white placeholder:text-[#5b5b6b] focus:border-violet-500/60 focus:outline-none"
            />
          )}
        </FieldGroup>

        <FieldGroup label="Cloaked launch" hint="Open Infinitesimal inside an opaque wrapper window.">
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => openInAboutBlank()}
              className="flex items-center gap-1.5 rounded-lg border border-[#23232f] bg-[#15151d] px-3 py-2 text-[12px] text-white hover:border-violet-500/40 hover:bg-[#181821]"
            >
              <Eye size={13} className="text-violet-300" /> Open in
              <code className="font-mono text-[11px] text-violet-300">about:blank</code>
            </button>
            <button
              onClick={() => openInBlob()}
              className="flex items-center gap-1.5 rounded-lg border border-[#23232f] bg-[#15151d] px-3 py-2 text-[12px] text-white hover:border-violet-500/40 hover:bg-[#181821]"
            >
              <EyeOff size={13} className="text-violet-300" /> Open in
              <code className="font-mono text-[11px] text-violet-300">blob:</code>
            </button>
          </div>
        </FieldGroup>

        <div className="flex items-center justify-end gap-2 border-t border-[#1f1f2a] pt-4">
          <button
            onClick={onClose}
            className="rounded-lg px-3 py-2 text-[12px] text-[#a2a2b0] hover:bg-[#1c1c27] hover:text-white"
          >
            Cancel
          </button>
          <button
            onClick={save}
            disabled={savingPw}
            className="rounded-lg bg-gradient-to-b from-violet-500 to-violet-600 px-4 py-2 text-[12px] font-medium text-white shadow-[0_4px_14px_-4px_rgba(139,92,246,0.6)] hover:from-violet-400 hover:to-violet-500 disabled:opacity-50"
          >
            {savingPw ? "Saving..." : "Save"}
          </button>
        </div>
      </div>
    </ModalShell>
  );
}

function Field({
  label,
  hint,
  children,
}: {
  label: string;
  hint?: string;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <div className="mb-1.5 text-[11px] font-medium uppercase tracking-[0.1em] text-[#7f7f8c]">
        {label}
      </div>
      {children}
      {hint && <div className="mt-1 text-[11px] text-[#6b6b78]">{hint}</div>}
    </label>
  );
}

function FieldGroup({
  label,
  hint,
  children,
}: {
  label: string;
  hint?: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <div className="mb-2">
        <div className="text-[12px] font-semibold text-white">{label}</div>
        {hint && <div className="text-[11px] text-[#7f7f8c]">{hint}</div>}
      </div>
      {children}
    </div>
  );
}

function RecoveryCodePanel({
  intro,
  code,
  onDone,
  doneLabel = "I've saved it",
}: {
  intro: string;
  code: string;
  onDone: () => void;
  doneLabel?: string;
}) {
  const [copied, setCopied] = useState(false);
  const [confirmed, setConfirmed] = useState(false);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      // ignore
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-start gap-3 rounded-lg border border-amber-500/30 bg-amber-500/10 px-3 py-2.5 text-[12px] text-amber-100">
        <KeyRound size={14} className="mt-0.5 shrink-0" />
        <span>{intro}</span>
      </div>

      <div className="rounded-lg border border-[#23232f] bg-[#15151d] p-4">
        <div className="mb-2 text-[10px] font-semibold uppercase tracking-[0.18em] text-[#7f7f8c]">
          Recovery code
        </div>
        <div className="flex items-center justify-between gap-2">
          <code className="select-all font-mono text-[15px] tracking-[0.12em] text-white">
            {code}
          </code>
          <button
            type="button"
            onClick={copy}
            className="flex items-center gap-1 rounded-md border border-[#23232f] bg-[#1c1c27] px-2.5 py-1.5 text-[11px] text-[#c2c2cc] hover:border-violet-500/40 hover:text-white"
          >
            {copied ? <Check size={12} className="text-emerald-300" /> : null}
            {copied ? "Copied" : "Copy"}
          </button>
        </div>
      </div>

      <label className="flex cursor-pointer items-center gap-2 text-[12px] text-[#c2c2cc]">
        <input
          type="checkbox"
          checked={confirmed}
          onChange={(e) => setConfirmed(e.target.checked)}
          className="h-3.5 w-3.5 accent-violet-500"
        />
        I've saved this code somewhere safe.
      </label>

      <div className="flex justify-end">
        <button
          type="button"
          disabled={!confirmed}
          onClick={onDone}
          className="rounded-lg bg-gradient-to-b from-violet-500 to-violet-600 px-4 py-2 text-[12px] font-medium text-white shadow-[0_4px_14px_-4px_rgba(139,92,246,0.6)] hover:from-violet-400 hover:to-violet-500 disabled:opacity-40"
        >
          {doneLabel}
        </button>
      </div>
    </div>
  );
}

function ProfileModal({
  user,
  onClose,
  onUpdated,
}: {
  user: AuthUser;
  onClose: () => void;
  onUpdated: (user: AuthUser) => void;
}) {
  const [displayName, setDisplayName] = useState(user.displayName ?? "");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);

  const initials =
    (user.displayName ?? user.email)
      .split(" ")
      .map((w) => w[0])
      .join("")
      .toUpperCase()
      .slice(0, 2) || "?";

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSaved(false);
    setBusy(true);
    try {
      const res = await apiFetch("/api/auth/profile", {
        method: "PATCH",
        body: JSON.stringify({ displayName: displayName.trim() || null }),
      });
      const data = (await res.json().catch(() => ({}))) as {
        user?: AuthUser;
        error?: string;
      };
      if (!res.ok || !data.user) {
        setError(data.error ?? "Could not update profile.");
        return;
      }
      setSaved(true);
      onUpdated(data.user);
      setTimeout(() => setSaved(false), 2000);
    } catch {
      setError("Network error. Please try again.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <ModalShell title="Your profile" icon={<UserRound size={16} />} onClose={onClose} width="max-w-sm">
      <div className="space-y-5">
        <div className="flex items-center gap-4">
          {user.avatarUrl ? (
            <img
              src={user.avatarUrl}
              alt="Avatar"
              className="h-14 w-14 rounded-full object-cover ring-2 ring-violet-500/30"
            />
          ) : (
            <div className="flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-br from-violet-500 to-fuchsia-500 text-[18px] font-bold text-white">
              {initials}
            </div>
          )}
          <div className="min-w-0 flex-1">
            <div className="truncate text-[15px] font-semibold text-white">
              {user.displayName || user.email}
            </div>
            <div className="truncate text-[12px] text-[#7f7f8c]">{user.email}</div>
          </div>
        </div>

        <form onSubmit={submit} className="space-y-4">
          <label className="block">
            <span className="mb-1 block text-[11px] font-medium uppercase tracking-wide text-[#8a8a99]">
              Display name
            </span>
            <input
              autoFocus
              type="text"
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              maxLength={80}
              placeholder="Your name"
              className="w-full rounded-lg border border-[#23232f] bg-[#15151d] px-3 py-2.5 text-[13px] text-white placeholder:text-[#5b5b6b] focus:border-violet-500/60 focus:outline-none"
            />
            <div className="mt-1 text-right text-[10px] text-[#5b5b6b]">{displayName.length}/80</div>
          </label>

          {error && (
            <div className="rounded-md border border-rose-500/30 bg-rose-500/10 px-3 py-2 text-[12px] text-rose-200">
              {error}
            </div>
          )}

          <div className="flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg px-4 py-2 text-[12px] text-[#8a8a99] hover:text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={busy}
              className="flex items-center gap-1.5 rounded-lg bg-gradient-to-b from-violet-500 to-violet-600 px-4 py-2 text-[12px] font-medium text-white shadow-[0_4px_14px_-4px_rgba(139,92,246,0.6)] hover:from-violet-400 hover:to-violet-500 disabled:opacity-60"
            >
              {busy ? (
                <Loader2 size={12} className="animate-spin" />
              ) : saved ? (
                <>
                  <Check size={12} className="text-emerald-200" /> Saved
                </>
              ) : (
                "Save changes"
              )}
            </button>
          </div>
        </form>
      </div>
    </ModalShell>
  );
}

type LoginMode = "login" | "signup" | "reset";

function LoginModal({
  onClose,
  onAuthed,
  googleAuthError,
}: {
  onClose: () => void;
  onAuthed: (user: AuthUser) => void;
  googleAuthError?: string | null;
}) {
  const [mode, setMode] = useState<LoginMode>("login");
  const [email, setEmail] = useState("");
  const [pw, setPw] = useState("");
  const [recovery, setRecovery] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(googleAuthError ?? null);
  const [issuedCode, setIssuedCode] = useState<{
    code: string;
    user: AuthUser;
    kind: "signup" | "reset";
  } | null>(null);

  const switchMode = (next: LoginMode) => {
    setMode(next);
    setError(null);
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    const trimmedEmail = email.trim();
    if (!trimmedEmail) {
      setError("Please enter your email.");
      return;
    }
    if (mode === "reset") {
      if (normalizeRecoveryCode(recovery).length < 8) {
        setError("Enter the recovery code you saved when you signed up.");
        return;
      }
      if (pw.length < 6) {
        setError("New password must be at least 6 characters.");
        return;
      }
    } else {
      if (pw.length < 6) {
        setError("Password must be at least 6 characters.");
        return;
      }
    }

    setBusy(true);
    try {
      let res: Response;
      if (mode === "reset") {
        res = await apiFetch("/api/auth/reset-password", {
          method: "POST",
          body: JSON.stringify({
            email: trimmedEmail,
            recoveryCode: recovery,
            newPassword: pw,
          }),
        });
      } else {
        res = await apiFetch(`/api/auth/${mode}`, {
          method: "POST",
          body: JSON.stringify({ email: trimmedEmail, password: pw }),
        });
      }

      const data = (await res.json().catch(() => ({}))) as {
        user?: AuthUser;
        recoveryCode?: string;
        error?: string;
        details?: string[];
      };

      if (!res.ok || !data.user) {
        const fallback =
          mode === "signup"
            ? "Could not create your account."
            : mode === "reset"
              ? "Could not reset your password."
              : "Could not sign you in.";
        const msg = data.error ?? fallback;
        setError(data.details?.[0] ? `${msg} (${data.details[0]})` : msg);
        return;
      }

      if ((mode === "signup" || mode === "reset") && data.recoveryCode) {
        setIssuedCode({ code: data.recoveryCode, user: data.user, kind: mode });
        return;
      }
      onAuthed(data.user);
    } catch {
      setError("Network error. Please try again.");
    } finally {
      setBusy(false);
    }
  };

  if (issuedCode) {
    const intro =
      issuedCode.kind === "signup"
        ? "Save this recovery code somewhere safe. If you ever forget your password, this is the only way to reset it. We won't show it again."
        : "Your password was reset. Save this new recovery code somewhere safe — your old one no longer works.";
    return (
      <ModalShell
        title="Recovery code"
        icon={<KeyRound size={16} />}
        onClose={() => onAuthed(issuedCode.user)}
        width="max-w-sm"
      >
        <RecoveryCodePanel
          intro={intro}
          code={issuedCode.code}
          onDone={() => onAuthed(issuedCode.user)}
          doneLabel="Continue"
        />
      </ModalShell>
    );
  }

  const title =
    mode === "signup"
      ? "Create account"
      : mode === "reset"
        ? "Reset password"
        : "Sign in";
  const heading =
    mode === "signup"
      ? "Create your account"
      : mode === "reset"
        ? "Reset your password"
        : "Welcome back";
  const subhead =
    mode === "signup"
      ? "Sign up with an email and password to save your sessions."
      : mode === "reset"
        ? "Enter the recovery code you saved when you signed up."
        : "Sign in to pick up where you left off.";
  const submitLabel =
    mode === "signup"
      ? "Create account"
      : mode === "reset"
        ? "Reset password"
        : "Sign in";

  return (
    <ModalShell title={title} icon={<LogIn size={16} />} onClose={onClose} width="max-w-sm">
      <form onSubmit={submit} className="space-y-4">
        <div className="flex flex-col items-center gap-2 pb-1 pt-2">
          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-violet-500 to-fuchsia-500 text-white">
            {mode === "reset" ? <KeyRound size={18} /> : <Sparkles size={18} />}
          </div>
          <div className="text-[15px] font-semibold text-white">{heading}</div>
          <div className="text-center text-[12px] text-[#8a8a99]">{subhead}</div>
        </div>

        <label className="block">
          <span className="mb-1 block text-[11px] font-medium uppercase tracking-wide text-[#8a8a99]">
            Email
          </span>
          <input
            autoFocus
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@example.com"
            autoComplete="email"
            className="w-full rounded-lg border border-[#23232f] bg-[#15151d] px-3 py-2.5 text-[13px] text-white placeholder:text-[#5b5b6b] focus:border-violet-500/60 focus:outline-none"
          />
        </label>

        {mode === "reset" && (
          <label className="block">
            <span className="mb-1 block text-[11px] font-medium uppercase tracking-wide text-[#8a8a99]">
              Recovery code
            </span>
            <input
              type="text"
              value={recovery}
              onChange={(e) => setRecovery(e.target.value)}
              placeholder="XXXX-XXXX-XXXX-XXXX"
              autoComplete="off"
              spellCheck={false}
              className="w-full rounded-lg border border-[#23232f] bg-[#15151d] px-3 py-2.5 font-mono text-[13px] tracking-[0.08em] text-white placeholder:text-[#5b5b6b] focus:border-violet-500/60 focus:outline-none"
            />
          </label>
        )}

        <label className="block">
          <span className="mb-1 block text-[11px] font-medium uppercase tracking-wide text-[#8a8a99]">
            {mode === "reset" ? "New password" : "Password"}
          </span>
          <div className="relative">
            <input
              type={showPw ? "text" : "password"}
              value={pw}
              onChange={(e) => setPw(e.target.value)}
              placeholder={
                mode === "login" ? "Your password" : "At least 6 characters"
              }
              autoComplete={mode === "login" ? "current-password" : "new-password"}
              className="w-full rounded-lg border border-[#23232f] bg-[#15151d] px-3 py-2.5 pr-9 text-[13px] text-white placeholder:text-[#5b5b6b] focus:border-violet-500/60 focus:outline-none"
            />
            <button
              type="button"
              onClick={() => setShowPw((v) => !v)}
              aria-label={showPw ? "Hide password" : "Show password"}
              className="absolute right-2 top-1/2 -translate-y-1/2 rounded p-1 text-[#7f7f8c] hover:text-white"
            >
              {showPw ? <EyeOff size={14} /> : <Eye size={14} />}
            </button>
          </div>
        </label>

        {error && (
          <div className="rounded-md border border-rose-500/30 bg-rose-500/10 px-3 py-2 text-[12px] text-rose-200">
            {error}
          </div>
        )}

        <button
          type="submit"
          disabled={busy}
          className="flex w-full items-center justify-center rounded-lg bg-gradient-to-b from-violet-500 to-violet-600 px-4 py-2.5 text-[13px] font-medium text-white shadow-[0_4px_14px_-4px_rgba(139,92,246,0.6)] hover:from-violet-400 hover:to-violet-500 disabled:opacity-60"
        >
          {busy ? <Loader2 size={14} className="animate-spin" /> : submitLabel}
        </button>

        {mode !== "reset" && (
          <>
            <div className="flex items-center gap-2">
              <div className="h-px flex-1 bg-[#23232f]" />
              <span className="text-[11px] text-[#5b5b6b]">or</span>
              <div className="h-px flex-1 bg-[#23232f]" />
            </div>
            <a
              href="/api/auth/google"
              className="flex w-full items-center justify-center gap-2.5 rounded-lg border border-[#2d2d3a] bg-[#18181f] px-4 py-2.5 text-[13px] font-medium text-[#d4d4e0] hover:border-[#3d3d50] hover:bg-[#1e1e2a] hover:text-white"
            >
              <svg width="16" height="16" viewBox="0 0 48 48" fill="none">
                <path d="M44.5 20H24v8.5h11.8C34.7 33.9 29.9 37 24 37c-7.2 0-13-5.8-13-13s5.8-13 13-13c3.1 0 5.9 1.1 8.1 2.9l6.4-6.4C34.6 5.1 29.6 3 24 3 12.4 3 3 12.4 3 24s9.4 21 21 21c10.5 0 20-7.8 20-21 0-1.4-.1-2.7-.5-4z" fill="#FFC107"/>
                <path d="M6.3 14.7l7 5.1C15 16.1 19.2 13 24 13c3.1 0 5.9 1.1 8.1 2.9l6.4-6.4C34.6 5.1 29.6 3 24 3c-7.6 0-14.2 4.2-17.7 10.7z" fill="#FF3D00"/>
                <path d="M24 45c5.5 0 10.5-1.9 14.4-5.1l-6.7-5.5C29.5 36.2 26.9 37 24 37c-5.8 0-10.7-3.9-12.4-9.3l-7 5.4C8 40.6 15.5 45 24 45z" fill="#4CAF50"/>
                <path d="M44.5 20H24v8.5h11.8c-.9 3-3.5 5.4-6.8 6.9l6.7 5.5C40.7 37.4 45 31.2 45 24c0-1.4-.1-2.7-.5-4z" fill="#1976D2"/>
              </svg>
              Continue with Google
            </a>
          </>
        )}

        <div className="space-y-1.5 text-center text-[12px] text-[#8a8a99]">
          {mode === "login" && (
            <>
              <div>
                No account yet?{" "}
                <button
                  type="button"
                  onClick={() => switchMode("signup")}
                  className="font-medium text-violet-300 hover:text-violet-200"
                >
                  Create one
                </button>
              </div>
              <div>
                <button
                  type="button"
                  onClick={() => switchMode("reset")}
                  className="font-medium text-violet-300 hover:text-violet-200"
                >
                  Forgot password?
                </button>
              </div>
            </>
          )}
          {mode === "signup" && (
            <div>
              Already have an account?{" "}
              <button
                type="button"
                onClick={() => switchMode("login")}
                className="font-medium text-violet-300 hover:text-violet-200"
              >
                Sign in
              </button>
            </div>
          )}
          {mode === "reset" && (
            <div>
              Remembered it?{" "}
              <button
                type="button"
                onClick={() => switchMode("login")}
                className="font-medium text-violet-300 hover:text-violet-200"
              >
                Back to sign in
              </button>
            </div>
          )}
        </div>
      </form>
    </ModalShell>
  );
}

function LockScreen({
  cloak,
  onUnlock,
  onResetLock,
  onPanic,
}: {
  cloak: CloakSettings;
  onUnlock: () => void;
  onResetLock: () => void;
  onPanic: () => void;
}) {
  const [pw, setPw] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [showReset, setShowReset] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!showReset) inputRef.current?.focus();
  }, [showReset]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    const hash = await hashPassword(pw);
    setBusy(false);
    if (hash === cloak.lockPasswordHash) {
      onUnlock();
    } else {
      setError("Wrong password.");
      setPw("");
    }
  };

  return (
    <div className="flex h-full w-full items-center justify-center bg-white text-slate-800">
      <div className="w-full max-w-sm px-6 py-12">
        <div className="flex flex-col items-center gap-4 text-center">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-slate-100 text-slate-500">
            <KeyRound size={20} />
          </div>
          <div>
            <div className="text-[18px] font-semibold text-slate-900">
              {cloak.title || "Sign in"}
            </div>
            <div className="mt-1 text-[13px] text-slate-500">
              {showReset
                ? "Reset access using your recovery code or your account."
                : "Enter your password to continue."}
            </div>
          </div>

          {!showReset ? (
            <>
              <form onSubmit={submit} className="mt-2 w-full space-y-2">
                <input
                  ref={inputRef}
                  type="password"
                  value={pw}
                  onChange={(e) => setPw(e.target.value)}
                  placeholder="Password"
                  className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2.5 text-[14px] text-slate-900 placeholder:text-slate-400 focus:border-slate-900 focus:outline-none"
                />
                {error && (
                  <div className="text-left text-[12px] text-rose-600">{error}</div>
                )}
                <button
                  type="submit"
                  disabled={busy}
                  className="w-full rounded-lg bg-slate-900 px-4 py-2.5 text-[13px] font-medium text-white hover:bg-slate-800 disabled:opacity-50"
                >
                  {busy ? "Checking..." : "Sign in"}
                </button>
              </form>
              <button
                onClick={() => setShowReset(true)}
                className="mt-2 text-[12px] text-slate-400 hover:text-slate-600"
              >
                Forgot password?
              </button>
            </>
          ) : (
            <LockResetPanel
              cloak={cloak}
              onCancel={() => setShowReset(false)}
              onSuccess={() => {
                onResetLock();
                onUnlock();
              }}
            />
          )}

          <button
            onClick={onPanic}
            className="mt-2 text-[11px] text-slate-300 hover:text-slate-500"
          >
            Leave site
          </button>
        </div>
      </div>
    </div>
  );
}

function LockResetPanel({
  cloak,
  onCancel,
  onSuccess,
}: {
  cloak: CloakSettings;
  onCancel: () => void;
  onSuccess: () => void;
}) {
  const [tab, setTab] = useState<"code" | "account">(
    cloak.lockRecoveryHash ? "code" : "account",
  );
  const [code, setCode] = useState("");
  const [email, setEmail] = useState("");
  const [pw, setPw] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const submitCode = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!cloak.lockRecoveryHash) {
      setError("No recovery code is set for this device.");
      return;
    }
    setBusy(true);
    const hash = await hashPassword(normalizeRecoveryCode(code));
    setBusy(false);
    if (hash === cloak.lockRecoveryHash) {
      onSuccess();
    } else {
      setError("That recovery code doesn't match.");
    }
  };

  const submitAccount = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!email.trim()) {
      setError("Enter your account email.");
      return;
    }
    if (pw.length < 6) {
      setError("Enter your account password.");
      return;
    }
    setBusy(true);
    try {
      const res = await apiFetch("/api/auth/login", {
        method: "POST",
        body: JSON.stringify({ email: email.trim(), password: pw }),
      });
      if (!res.ok) {
        setError("Those credentials don't match an account.");
        return;
      }
      onSuccess();
    } catch {
      setError("Network error. Please try again.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="mt-2 w-full space-y-3">
      <div className="grid grid-cols-2 gap-1 rounded-lg bg-slate-100 p-1 text-[12px]">
        <button
          type="button"
          onClick={() => {
            setTab("code");
            setError(null);
          }}
          className={`rounded-md px-3 py-1.5 transition-colors ${
            tab === "code"
              ? "bg-white text-slate-900 shadow-sm"
              : "text-slate-500 hover:text-slate-700"
          }`}
        >
          Recovery code
        </button>
        <button
          type="button"
          onClick={() => {
            setTab("account");
            setError(null);
          }}
          className={`rounded-md px-3 py-1.5 transition-colors ${
            tab === "account"
              ? "bg-white text-slate-900 shadow-sm"
              : "text-slate-500 hover:text-slate-700"
          }`}
        >
          Account
        </button>
      </div>

      {tab === "code" ? (
        <form onSubmit={submitCode} className="space-y-2 text-left">
          <input
            autoFocus
            type="text"
            value={code}
            onChange={(e) => setCode(e.target.value)}
            placeholder="XXXX-XXXX-XXXX-XXXX"
            spellCheck={false}
            autoComplete="off"
            className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2.5 font-mono text-[14px] tracking-[0.08em] text-slate-900 placeholder:text-slate-300 focus:border-slate-900 focus:outline-none"
          />
          {error && <div className="text-[12px] text-rose-600">{error}</div>}
          <button
            type="submit"
            disabled={busy}
            className="w-full rounded-lg bg-slate-900 px-4 py-2.5 text-[13px] font-medium text-white hover:bg-slate-800 disabled:opacity-50"
          >
            {busy ? "Checking..." : "Unlock and remove lock"}
          </button>
        </form>
      ) : (
        <form onSubmit={submitAccount} className="space-y-2 text-left">
          <input
            autoFocus
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Account email"
            autoComplete="email"
            className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2.5 text-[14px] text-slate-900 placeholder:text-slate-400 focus:border-slate-900 focus:outline-none"
          />
          <input
            type="password"
            value={pw}
            onChange={(e) => setPw(e.target.value)}
            placeholder="Account password"
            autoComplete="current-password"
            className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2.5 text-[14px] text-slate-900 placeholder:text-slate-400 focus:border-slate-900 focus:outline-none"
          />
          {error && <div className="text-[12px] text-rose-600">{error}</div>}
          <button
            type="submit"
            disabled={busy}
            className="w-full rounded-lg bg-slate-900 px-4 py-2.5 text-[13px] font-medium text-white hover:bg-slate-800 disabled:opacity-50"
          >
            {busy ? "Checking..." : "Sign in and remove lock"}
          </button>
        </form>
      )}

      <button
        type="button"
        onClick={onCancel}
        className="w-full text-[12px] text-slate-400 hover:text-slate-600"
      >
        Back to password
      </button>
    </div>
  );
}

export default App;
