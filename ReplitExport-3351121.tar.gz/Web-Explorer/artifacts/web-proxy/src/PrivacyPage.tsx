import { Sparkles, ArrowLeft } from "lucide-react";

export default function PrivacyPage() {
  return (
    <div className="min-h-screen bg-[#0b0b10] text-[#e7e7ee]">
      <div className="mx-auto max-w-2xl px-6 py-16">

        {/* Header */}
        <a
          href="/"
          className="mb-10 flex items-center gap-2 text-[13px] text-[#7f7f8c] hover:text-white"
        >
          <ArrowLeft size={14} />
          Back to Infinitesimal
        </a>

        <div className="mb-8 flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-violet-500 to-fuchsia-500">
            <Sparkles size={18} className="text-white" />
          </div>
          <div>
            <div className="text-[22px] font-semibold text-white">Privacy Policy</div>
            <div className="text-[12px] text-[#5b5b6b]">Last updated: {new Date().toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" })}</div>
          </div>
        </div>

        <div className="space-y-8 text-[14px] leading-relaxed text-[#b2b2c2]">

          <section>
            <h2 className="mb-3 text-[16px] font-semibold text-white">Overview</h2>
            <p>
              Infinitesimal ("we", "our", or "us") is a web proxy application that lets you browse the web privately. This Privacy Policy explains what information we collect, how we use it, and your rights regarding that information.
            </p>
          </section>

          <section>
            <h2 className="mb-3 text-[16px] font-semibold text-white">Information We Collect</h2>
            <ul className="list-disc space-y-2 pl-5">
              <li>
                <strong className="text-white">Account information:</strong> When you create an account, we store your email address and a hashed (bcrypt) version of your password. We never store your password in plain text.
              </li>
              <li>
                <strong className="text-white">Google Sign-In:</strong> If you sign in with Google, we receive your email address, display name, and profile photo from Google. We store these to identify your account.
              </li>
              <li>
                <strong className="text-white">Session data:</strong> We store a secure session token in your browser (as a cookie) to keep you signed in. Session data is stored server-side in a PostgreSQL database.
              </li>
              <li>
                <strong className="text-white">Local preferences:</strong> Your browsing preferences (search engine, cloak settings, bookmarks) are stored locally in your browser's localStorage and are never sent to our servers.
              </li>
            </ul>
          </section>

          <section>
            <h2 className="mb-3 text-[16px] font-semibold text-white">Information We Do Not Collect</h2>
            <ul className="list-disc space-y-2 pl-5">
              <li>We do not log or store the URLs you visit through the proxy.</li>
              <li>We do not track your browsing history.</li>
              <li>We do not sell your personal information to third parties.</li>
              <li>We do not use advertising or analytics trackers.</li>
            </ul>
          </section>

          <section>
            <h2 className="mb-3 text-[16px] font-semibold text-white">How We Use Your Information</h2>
            <ul className="list-disc space-y-2 pl-5">
              <li>To create and maintain your account.</li>
              <li>To authenticate you when you sign in.</li>
              <li>To allow you to recover your account using a recovery code.</li>
              <li>To display your display name and avatar in the application.</li>
            </ul>
          </section>

          <section>
            <h2 className="mb-3 text-[16px] font-semibold text-white">Third-Party Services</h2>
            <p className="mb-2">
              Infinitesimal uses the following third-party services:
            </p>
            <ul className="list-disc space-y-2 pl-5">
              <li>
                <strong className="text-white">Google OAuth:</strong> If you choose "Sign in with Google", you will be redirected to Google's authentication service. Google's <a href="https://policies.google.com/privacy" className="text-violet-300 hover:underline" target="_blank" rel="noopener noreferrer">Privacy Policy</a> applies to that interaction.
              </li>
              <li>
                <strong className="text-white">Proxy backends:</strong> Pages you visit are fetched by our server on your behalf. Optionally, AllOrigins (<a href="https://allorigins.win" className="text-violet-300 hover:underline" target="_blank" rel="noopener noreferrer">allorigins.win</a>) or CORS Proxy may be used as alternate backends when selected.
              </li>
            </ul>
          </section>

          <section>
            <h2 className="mb-3 text-[16px] font-semibold text-white">Data Retention</h2>
            <p>
              Your account data (email, password hash) is retained until you delete your account or request removal. Session cookies expire after 30 days of inactivity.
            </p>
          </section>

          <section>
            <h2 className="mb-3 text-[16px] font-semibold text-white">Your Rights</h2>
            <p>
              You may request deletion of your account and associated data at any time by contacting us. You can also sign out at any time, which will clear your session cookie.
            </p>
          </section>

          <section>
            <h2 className="mb-3 text-[16px] font-semibold text-white">Changes to This Policy</h2>
            <p>
              We may update this Privacy Policy from time to time. Continued use of the application after changes constitutes acceptance of the updated policy.
            </p>
          </section>

        </div>

        <div className="mt-12 border-t border-[#1f1f2a] pt-8 text-center text-[12px] text-[#4b4b5b]">
          © {new Date().getFullYear()} Infinitesimal. All rights reserved.
        </div>
      </div>
    </div>
  );
}
