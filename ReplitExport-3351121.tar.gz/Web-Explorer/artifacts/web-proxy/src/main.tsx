import { createRoot } from "react-dom/client";
import App from "./App";
import PrivacyPage from "./PrivacyPage";
import "./index.css";

const root = document.getElementById("root")!;
const path = window.location.pathname;

if (path === "/privacy" || path === "/privacy/") {
  createRoot(root).render(<PrivacyPage />);
} else {
  createRoot(root).render(<App />);
}
