export interface CloakPreset {
  id: string;
  label: string;
  title: string;
  faviconDomain: string;
}

export const CLOAK_PRESETS: CloakPreset[] = [
  { id: "default", label: "Infinitesimal", title: "Infinitesimal", faviconDomain: "" },
  { id: "google", label: "Google", title: "Google", faviconDomain: "google.com" },
  { id: "classroom", label: "Google Classroom", title: "Home", faviconDomain: "classroom.google.com" },
  { id: "docs", label: "Google Docs", title: "Untitled document - Google Docs", faviconDomain: "docs.google.com" },
  { id: "drive", label: "Google Drive", title: "My Drive - Google Drive", faviconDomain: "drive.google.com" },
  { id: "gmail", label: "Gmail", title: "Inbox - Gmail", faviconDomain: "mail.google.com" },
  { id: "khan", label: "Khan Academy", title: "Khan Academy | Free Online Courses", faviconDomain: "khanacademy.org" },
  { id: "schoology", label: "Schoology", title: "Home | Schoology", faviconDomain: "schoology.com" },
  { id: "canvas", label: "Canvas", title: "Dashboard", faviconDomain: "canvas.instructure.com" },
  { id: "wikipedia", label: "Wikipedia", title: "Wikipedia, the free encyclopedia", faviconDomain: "wikipedia.org" },
  { id: "blank", label: "Blank", title: "", faviconDomain: "" },
];

const FAVICON_ID = "app-favicon";
const DEFAULT_FAVICON = "/favicon.svg";

export function googleFaviconUrl(domain: string): string {
  if (!domain) return DEFAULT_FAVICON;
  return `https://www.google.com/s2/favicons?domain=${encodeURIComponent(domain)}&sz=64`;
}

export function applyTitle(title: string) {
  document.title = title || " ";
}

export function applyFavicon(href: string) {
  let link = document.getElementById(FAVICON_ID) as HTMLLinkElement | null;
  if (!link) {
    link = document.createElement("link");
    link.id = FAVICON_ID;
    link.rel = "icon";
    document.head.appendChild(link);
  }
  link.type = href.endsWith(".svg") ? "image/svg+xml" : "image/x-icon";
  link.href = href || DEFAULT_FAVICON;
}

export function openInAboutBlank(targetUrl?: string) {
  const url = targetUrl || window.location.href;
  const win = window.open("about:blank", "_blank");
  if (!win) {
    alert(
      "Couldn't open a new window. Please allow popups for this site, then try again.",
    );
    return false;
  }
  const title = document.title || "Loading";
  const favicon =
    (document.getElementById(FAVICON_ID) as HTMLLinkElement | null)?.href || "";
  win.document.open();
  win.document.write(`<!doctype html>
<html><head>
<title>${escapeHtml(title)}</title>
${favicon ? `<link rel="icon" href="${escapeAttr(favicon)}">` : ""}
<style>html,body,iframe{margin:0;padding:0;border:0;height:100%;width:100%;}body{background:#fff;}</style>
</head>
<body><iframe src="${escapeAttr(url)}" allow="fullscreen; clipboard-read; clipboard-write" allowfullscreen></iframe></body></html>`);
  win.document.close();
  try {
    setTimeout(() => {
      window.location.replace("https://www.google.com/");
    }, 250);
  } catch {}
  return true;
}

export function openInBlob(targetUrl?: string) {
  const url = targetUrl || window.location.href;
  const title = document.title || "Loading";
  const favicon =
    (document.getElementById(FAVICON_ID) as HTMLLinkElement | null)?.href || "";
  const html = `<!doctype html>
<html><head>
<title>${escapeHtml(title)}</title>
${favicon ? `<link rel="icon" href="${escapeAttr(favicon)}">` : ""}
<style>html,body,iframe{margin:0;padding:0;border:0;height:100%;width:100%;}body{background:#fff;}</style>
</head>
<body><iframe src="${escapeAttr(url)}" allow="fullscreen; clipboard-read; clipboard-write" allowfullscreen></iframe></body></html>`;
  const blob = new Blob([html], { type: "text/html" });
  const blobUrl = URL.createObjectURL(blob);
  const win = window.open(blobUrl, "_blank");
  if (!win) {
    URL.revokeObjectURL(blobUrl);
    alert(
      "Couldn't open a new window. Please allow popups for this site, then try again.",
    );
    return false;
  }
  setTimeout(() => URL.revokeObjectURL(blobUrl), 60_000);
  try {
    setTimeout(() => {
      window.location.replace("https://www.google.com/");
    }, 250);
  } catch {}
  return true;
}

function escapeHtml(s: string) {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function escapeAttr(s: string) {
  return escapeHtml(s).replace(/"/g, "&quot;");
}
