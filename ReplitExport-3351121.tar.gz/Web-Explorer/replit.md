# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Each package manages its own dependencies.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)

## Artifacts

- `web-proxy` (`/`) — **Infinitesimal**, browser-style web proxy UI. Features: search/URL bar with selectable engine (Google, DuckDuckGo, Brave), selectable proxy backend (Direct, AllOrigins, CORS Proxy), back/forward/reload, bookmarks, cloak menu (tab title + favicon spoof presets via Google's `s2/favicons`), about:blank and blob: launchers (window cloak), panic button + configurable panic key + redirect URL, real email+password signup/login with persistent server-side sessions (toolbar shows current user + sign out, signup issues a one-time recovery code), optional password lock screen (SHA-256 hash, localStorage; setting one issues a one-time recovery code). Both lock screens (account login and cloak password lock) have a "Forgot password?" path. Cloak/bookmark settings persist client-side; auth state lives on the server.
- `api-server` (`/api`) — Express server. Proxy routes: `GET /api/proxy/page?url=...&backend=direct|allorigins|corsproxy` returns rewritten HTML with all links/assets routed back through the proxy (preserving the chosen backend); `GET /api/proxy/asset?url=...&backend=...` proxies binary assets and rewrites CSS `url()` references. The `direct` backend fetches directly; `allorigins` wraps via `api.allorigins.win`; `corsproxy` wraps via `corsproxy.io`. Auth routes: `POST /api/auth/signup` (returns user + one-time `recoveryCode`), `POST /api/auth/login`, `POST /api/auth/reset-password` (verifies email + recovery code, sets new password, rotates and returns a fresh `recoveryCode`), `POST /api/auth/logout`, `GET /api/auth/me`. Bcrypt for password and recovery-code hashes, `express-session` with `connect-pg-simple` (table `user_sessions`, manually created), cookie name `infinitesimal.sid`, 30-day rolling sessions. No email verification.

## Recovery flows

- **Account password**: at signup the server issues a one-time recovery code (`XXXX-XXXX-XXXX-XXXX`, 64-bit hex) shown once in the UI. The login modal's "Forgot password?" path calls `POST /api/auth/reset-password` with email + code + new password; the server rotates the code and returns the new one to display.
- **Cloak password lock**: setting a lock password in Settings generates a recovery code stored as SHA-256 in `cloak.lockRecoveryHash` (localStorage). The lock screen's "Forgot password?" path offers two tabs — recovery code (matched against the local hash) or account credentials (calls `/api/auth/login`). Either successful path unlocks AND removes the lock entirely.

## Database

- `users` (`lib/db/src/schema/users.ts`) — `id` (uuid pk), `email` (unique), `password_hash`, `recovery_code_hash` (nullable bcrypt of the normalized code), `created_at`. Managed via `pnpm --filter @workspace/db run push`. Column additions made directly via SQL when the push command would otherwise drop the manually-managed `user_sessions` table.
- `user_sessions` — created manually for `connect-pg-simple` (esbuild can't bundle its `table.sql`). Standard schema: `sid` (pk), `sess` (json), `expire` (timestamp).

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/api-server run dev` — run API server locally

See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details.
