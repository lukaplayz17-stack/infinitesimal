# Discord Bot with YouTube Integration

## Overview

This is a Discord bot built with Discord.js v14 that provides two core functionalities:
1. **YouTube Integration**: Monitors a YouTube channel for new uploads and posts notifications to a designated Discord channel
2. **Member Verification System**: Implements a button-based verification system for new server members

The bot is designed as a lightweight, single-file Node.js application that runs continuously to track YouTube activity and manage Discord server interactions.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Bot Framework
- **Discord.js v14**: The bot uses Discord.js as its core framework for interacting with the Discord API
- **Gateway Intents**: Configured with Guilds, GuildMembers, GuildMessages, and MessageContent intents to handle server events and message interactions
- **Partials**: Enabled for Message, Channel, and Reaction to ensure incomplete data structures are cached

### Event-Driven Architecture
The bot follows an event-driven pattern with two main event handlers:

1. **Ready Event**: Initializes YouTube monitoring with a 60-second polling interval when the bot starts
2. **GuildMemberAdd Event**: Triggers verification flow when new members join the server

### YouTube Monitoring System
- **Polling-based approach**: The bot checks for new videos every 60 seconds using a setInterval timer
- **State tracking**: Uses a `lastVideoId` variable to track the most recent video and detect new uploads
- **External API integration**: Integrates with YouTube Data API v3 to fetch channel upload data
- **Conditional activation**: YouTube monitoring only activates if all required environment variables are set (YOUTUBE_CHANNEL_ID, YOUTUBE_API_KEY, DISCORD_CHANNEL_ID)

**Rationale**: Polling was chosen over webhooks for simplicity and ease of deployment, avoiding the need for public endpoints or webhook management. The 60-second interval balances responsiveness with API quota conservation.

### Verification System
- **Interactive components**: Uses Discord's button components (ActionRowBuilder, ButtonBuilder) for user verification
- **Embed-based messaging**: Leverages EmbedBuilder for rich, formatted welcome messages
- **Member mentions**: Tags new members in verification messages for immediate notification

**Rationale**: Button-based verification provides a user-friendly, modern interaction pattern that's harder to bypass than message-based verification while remaining accessible to all users.

### Configuration Management
- **Environment variables**: All sensitive data and channel IDs are externalized through environment variables
- **Fallback values**: Provides empty string defaults to prevent crashes when variables are missing
- **Prefix-based commands**: Uses "!" as the command prefix (infrastructure present but commands not implemented in current codebase)

### Error Handling
- **Silent failures**: The bot uses early returns (e.g., `if (!channel) return;`) to gracefully handle missing channels
- **Conditional feature activation**: YouTube monitoring gracefully disables if required configuration is missing

## External Dependencies

### Discord API
- **discord.js v14.22.1**: Primary framework for Discord bot functionality
- **Required scopes**: Bot requires guild, member, and message-related permissions
- **Gateway connection**: Maintains persistent WebSocket connection to Discord's gateway

### YouTube Data API v3
- **Purpose**: Fetches latest video uploads from a specified YouTube channel
- **Authentication**: Requires API key stored in YOUTUBE_API_KEY environment variable
- **API endpoint**: Likely uses the `search` or `playlistItems` endpoint to retrieve channel uploads

### HTTP Client
- **node-fetch v3.3.2**: Used for making HTTP requests to external APIs (YouTube)
- **Rationale**: Chosen for its lightweight, Promise-based API that mirrors browser fetch

### Environment Variables Required
- `YOUTUBE_CHANNEL_ID`: The YouTube channel ID to monitor
- `YOUTUBE_API_KEY`: API key for YouTube Data API v3 access
- `DISCORD_CHANNEL_ID`: Discord channel ID where YouTube notifications are posted
- `WELCOME_CHANNEL_ID`: Discord channel ID for member verification messages
- `DISCORD_BOT_TOKEN`: Bot token for Discord authentication (implied, not visible in code)

### Runtime Environment
- **Node.js**: Requires version 16.11.0 or higher (per discord.js requirements)
- **No database**: Current implementation uses in-memory state (lastVideoId variable)

**Note**: The codebase appears incomplete with truncated event handlers, suggesting the full implementation includes additional logic for button interactions and YouTube video posting.