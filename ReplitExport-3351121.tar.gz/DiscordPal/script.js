const CLERK_FRONTEND_API = "https://able-trout-76.clerk.accounts.dev"; // from Clerk dashboard

(async () => {
  const Clerk = window.Clerk;
  await Clerk.load({ frontendApi: CLERK_FRONTEND_API });

  const signIn = document.getElementById("sign-in");
  const profile = document.getElementById("user-profile");
  const app = document.getElementById("app");

  Clerk.mountSignIn(signIn);
  Clerk.mountUserProfile(profile);

  Clerk.addListener(({ user }) => {
    if (user) {
      signIn.style.display = "none";
      profile.style.display = "block";
      app.style.display = "block";
      loadPosts();
    } else {
      signIn.style.display = "block";
      profile.style.display = "none";
      app.style.display = "none";
    }
  });
})();

const form = document.getElementById("postForm");
const input = document.getElementById("postInput");
const container = document.getElementById("postsContainer");

// Fetch and render posts
async function loadPosts() {
  const res = await fetch("/api/posts");
  const posts = await res.json();
  container.innerHTML = "";
  posts.reverse().forEach(p => {
    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = `
      <div class="card-content">${p.content}</div>
      <div class="card-author">👤 ${p.username}</div>
      <div class="card-timestamp">${p.timestamp}</div>
    `;
    container.appendChild(card);
  });
}

// Create post
form.addEventListener("submit", async e => {
  e.preventDefault();
  const text = input.value.trim();
  if (!text) return;

  const user = window.Clerk.user;
  const username = user?.username || user?.fullName || "Anonymous";

  await fetch("/api/posts", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ content: text, username }),
  });

  input.value = "";
  loadPosts();
});
