import express from "express";
import bodyParser from "body-parser";
import { Database } from "@replit/database";
import path from "path";
import { fileURLToPath } from "url";

const app = express();
const db = new Database();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

app.use(express.static(path.join(__dirname, "public")));
app.use(bodyParser.json());

// Get all posts
app.get("/api/posts", async (req, res) => {
  let posts = await db.get("posts");
  if (!posts) posts = [];
  res.json(posts);
});

// Create a new post
app.post("/api/posts", async (req, res) => {
  const { content, username } = req.body;
  if (!content || !username)
    return res.status(400).json({ error: "Missing content or username" });

  let posts = await db.get("posts");
  if (!posts) posts = [];

  const newPost = {
    id: Date.now(),
    content,
    username,
    timestamp: new Date().toLocaleString(),
  };

  posts.push(newPost);
  await db.set("posts", posts);
  res.json(newPost);
});

// Edit a post
app.put("/api/posts/:id", async (req, res) => {
  const { id } = req.params;
  const { content } = req.body;

  let posts = await db.get("posts");
  if (!posts) posts = [];

  const index = posts.findIndex(p => p.id == id);
  if (index === -1) return res.status(404).json({ error: "Post not found" });

  posts[index].content = content;
  await db.set("posts", posts);

  res.json(posts[index]);
});

// Delete a post
app.delete("/api/posts/:id", async (req, res) => {
  const { id } = req.params;
  let posts = await db.get("posts");
  if (!posts) posts = [];

  posts = posts.filter(p => p.id != id);
  await db.set("posts", posts);

  res.json({ success: true });
});

app.listen(3000, () => console.log("✅ Server running on port 3000"));
